<?php
if (did_action('add_modal_book_done')) return;
do_action('add_modal_book_done');

$modal_book_ember = carbon_get_theme_option('modal-book-ember');
$modal_book_title = knot_crb_theme('modal-book-title');
$modal_book_text = knot_crb_theme('modal-book-text');

if ($modal_book_ember) : ?>
    <div class="modal" id="modal-book" style="display: none">
        <div class="modal-wrapper">
            <button class="modal_close" data-action="close">
                <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="20" cy="20" r="20" fill="white"/>
                    <circle cx="20" cy="20" r="19.5" stroke="black" stroke-opacity="0.1"/>
                    <path d="M26 14L14 26M26 26L14 14" stroke="black" stroke-width="2.5" stroke-linecap="round"
                          stroke-linejoin="round"/>
                </svg>
            </button>
                <div class="modal_book">
                    <?php echo $modal_book_ember; ?>
                </div>
        </div>
    </div>
<?php endif; ?>