<?php
$case_terms = wp_get_post_terms(get_the_ID(), 'case_category', array('fields' => 'slugs'));
$case_terms_str = implode(',', $case_terms);
?>
<article class="project" data-category="<?php echo esc_attr($case_terms_str); ?>">
    <?php
    $case_terms = wp_get_post_terms(get_the_ID(), 'case_category');
    if (!empty($case_terms) && !is_wp_error($case_terms)) : ?>
        <ul class="project-tabs">
            <?php foreach ($case_terms as $term) : ?>
                <li><?php echo esc_html($term->name); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <a class="project-image" href="<?php the_permalink(); ?>">
        <?php if (has_post_thumbnail()) : ?>
            <?php the_post_thumbnail('full'); ?>
        <?php else : ?>

            <?php echo knot_image_dir('none', '.png'); ?>
        <?php endif; ?>
    </a>
    <div class="project-content content">
        <a class="title h4" href="<?php the_permalink(); ?>">
            <h3><?php the_title(); ?></h3>
        </a>
        <?php the_excerpt(); ?>
    </div>
</article>