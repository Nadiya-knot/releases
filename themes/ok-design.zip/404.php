<?php
get_header();

$image = knot_crb_theme('error-404-image');
?>

    <main>
        <section class="error-404">
            <div class="container">
                <div class="error-404__content content">
                    <?php if (!empty($image)): ?>
                        <div class="error-404__img">
                            <?php echo knot_image($image); ?>
                        </div>
                    <?php endif; ?>

                    <?php
                    echo KnotContent::renderContent(
                            knot_crb_theme('error-404-title'),
                            knot_crb_theme('error-404-text'),
                            [
                                    'button_type' => 'link',
                                    'button_text' => 'Back to Home',
                                    'button_link' => home_url(),
                            ],
                            false,
                            '',
                            'title h1',
                    );
                    ?>
                </div>
            </div>
        </section>
    </main>

    <style>
        body {
            display: flex;
            flex-direction: column;

            min-height: 100dvh;
        }

        main {
            display: flex;
            align-items: center;
            justify-content: center;

            flex: 1;
        }

        .error-404 {
            margin: 0 !important;
        }

        .error-404__content {
            align-items: center;

            max-width: 680px;
            margin-block: var(--i1);
            text-align: center;
            text-wrap: balance;
        }

        .error-404__img {
            max-width: 512px;
        }
    </style>

<?php
get_footer();