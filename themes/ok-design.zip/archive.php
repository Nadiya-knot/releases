<?php get_header(); ?>

    <main>

        <section class="projects">
            <div class="container">
                <div class="projects-top content">
                    <div class="title h2">
                        <h2>See What We’ve Built</h2>
                    </div>
                </div>

                <?php
                $terms = get_terms(array(
                        'taxonomy' => 'case_category',
                        'hide_empty' => true,
                ));
                ?>

                <?php if (!empty($terms) && !is_wp_error($terms)) : ?>
                    <div class="projects-tabs">
                        <?php $cases_url = get_post_type_archive_link('cases'); ?>
                        <a href="<?php echo $cases_url; ?>" class="active" data-filter="all">All</a>
                        <?php foreach ($terms as $term) : ?>
                            <a href="<?php echo $cases_url . '?category=' . esc_attr($term->slug); ?>"
                               data-filter="<?php echo esc_attr($term->slug); ?>">
                                <?php echo esc_html($term->name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="projects-list grid-two">
                    <?php
                    $cases_query = new WP_Query(array(
                            'post_type' => 'cases',
                            'posts_per_page' => -1
                    ));

                    if ($cases_query->have_posts()) :
                        while ($cases_query->have_posts()) : $cases_query->the_post();
                            $case_terms = wp_get_post_terms(get_the_ID(), 'case_category', array('fields' => 'slugs'));
                            $case_terms_str = implode(',', $case_terms);
                            ?>
                            <article class="project" data-category="<?php echo esc_attr($case_terms_str); ?>">
                                <a class="project-image" href="<?php the_permalink(); ?>">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <?php the_post_thumbnail('full'); ?>
                                    <?php else : ?>

                                        <?php echo knot_image_dir('none', '.png'); ?>
                                    <?php endif; ?>
                                </a>
                                <div class="project-content content">
                                    <a class="title h4" href="<?php the_permalink(); ?>">
                                        <h3><?php the_title(); ?></h3>
                                    </a>
                                    <?php the_excerpt(); ?>
                                </div>
                            </article>
                        <?php
                        endwhile;
                        wp_reset_postdata();
                    else :
                        echo '<p>Кейси не знайдено.</p>';
                    endif;
                    ?>
                </div>
            </div>
        </section>
    </main>

    <script>
        const projects = document.querySelectorAll('.projects-list .project');
        const tabs = document.querySelectorAll('.projects-tabs a');

        function filterProjects(category) {
            projects.forEach(project => {
                const categories = project.dataset.category.split(',');
                project.style.display = (category === 'all' || categories.includes(category)) ? 'block' : 'none';
            });
        }

        function setActiveTab(category) {
            tabs.forEach(tab => {
                tab.classList.toggle('active', tab.dataset.filter === category);
            });
        }

        const urlParams = new URLSearchParams(window.location.search);
        const initialCategory = urlParams.get('category') || 'all';
        filterProjects(initialCategory);
        setActiveTab(initialCategory);

        tabs.forEach(tab => {
            tab.addEventListener('click', (e) => {
                e.preventDefault();

                const href = tab.getAttribute('href');
                const category = tab.dataset.filter;
                filterProjects(category);
                setActiveTab(category);

                history.pushState(null, '', href);
            });
        });

        window.addEventListener('popstate', (e) => {
            const category = (e.state && e.state.category) || 'all';
            filterProjects(category);
            setActiveTab(category);
        });
    </script>

<?php get_footer();