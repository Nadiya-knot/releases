<?php get_header(); ?>

    <main>

        <section class="projects">
            <div class="container">
                <div class="projects-top content">
                    <div class="title h2">
                        <h2>See What We’ve Built</h2>
                    </div>
                </div>

                <?php
                $terms = get_terms(array(
                        'taxonomy' => 'case_category',
                        'hide_empty' => true,
                ));
                ?>

                <?php if (!empty($terms) && !is_wp_error($terms)) : ?>
                    <div class="projects-tabs">
                        <?php
                        $cases_url = get_post_type_archive_link('cases');
                        $current = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : 'all';
                        ?>

                        <a href="<?php echo $cases_url; ?>"
                           class="<?php echo $current === 'all' ? 'active' : ''; ?>"
                           data-filter="all">All</a>

                        <?php foreach ($terms as $term) :
                            $slug = esc_attr($term->slug);
                            $is_active = ($current === $slug) ? 'active' : '';
                            ?>
                            <a href="<?php echo $cases_url . '?category=' . $slug; ?>"
                               class="<?php echo $is_active; ?>"
                               data-filter="<?php echo $slug; ?>">
                                <?php echo esc_html($term->name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="projects-list grid-two">
                    <?php
                    $cases_query = new WP_Query(array(
                            'post_type' => 'cases',
                            'posts_per_page' => -1
                    ));

                    if ($cases_query->have_posts()) :
                        while ($cases_query->have_posts()) : $cases_query->the_post(); ?>
                            <?php get_template_part('templates/post', get_post_type()); ?>
                        <?php
                        endwhile;
                        wp_reset_postdata();
                    else :
                        echo '<p>Кейси не знайдено.</p>';
                    endif;
                    ?>
                </div>
            </div>
        </section>
    </main>

    <script>
        const projects = document.querySelectorAll('.projects-list .project');
        const tabs = document.querySelectorAll('.projects-tabs a');

        function filterProjects(category) {
            projects.forEach(project => {
                const categories = project.dataset.category.split(',');
                project.style.display = (category === 'all' || categories.includes(category)) ? 'block' : 'none';
            });
        }

        function setActiveTab(category) {
            tabs.forEach(tab => {
                tab.classList.toggle('active', tab.dataset.filter === category);
            });
        }

        const urlParams = new URLSearchParams(window.location.search);
        const initialCategory = urlParams.get('category') || 'all';
        filterProjects(initialCategory);
        setActiveTab(initialCategory);

        tabs.forEach(tab => {
            tab.addEventListener('click', (e) => {
                e.preventDefault();

                const href = tab.getAttribute('href');
                const category = tab.dataset.filter;
                filterProjects(category);
                setActiveTab(category);

                history.pushState(null, '', href);
            });
        });

        window.addEventListener('popstate', (e) => {
            const category = (e.state && e.state.category) || 'all';
            filterProjects(category);
            setActiveTab(category);
        });
    </script>

<?php get_footer();