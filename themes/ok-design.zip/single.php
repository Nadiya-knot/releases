<?php get_header(); ?>

    <main>
        <?php while (have_posts()) : the_post(); ?>
            <section class="case">
                <div class="container">
                    <div class="case-head content">
                        <?php
                        $previous_url = wp_get_referer(); // отримуємо попередню сторінку
                        $cases_archive = get_post_type_archive_link('cases'); // архів CPT Cases

                        // Перевіряємо, чи попередня сторінка є на вашому домені
                        if ($previous_url && strpos($previous_url, home_url()) === 0) {
                            $back_link = $previous_url;
                        } else {
                            $back_link = $cases_archive;
                        }
                        ?>
                        <a href="<?php echo esc_url($back_link); ?>">Go back</a>

                        <div class="title h1">
                            <?php the_title('<h1>', '</h1>'); ?>
                        </div>

                        <?php $terms = get_the_terms(get_the_ID(), 'case_category'); ?>
                        <?php if ($terms && !is_wp_error($terms)) : ?>
                            <div class="case-tabs">
                                <?php foreach ($terms as $term) : ?>
                                    <a class="case-tab"
                                       href="<?php echo esc_url(add_query_arg('category', $term->slug, get_post_type_archive_link('cases'))); ?>">
                                        <?php echo esc_html($term->name); ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <?php if (has_excerpt()) : ?>
                            <div class="richText fs-h4">
                                <?php the_excerpt(); ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if (has_post_thumbnail()) : ?>
                        <div class="case-image">
                            <?php the_post_thumbnail('full', array('class' => 'img-fluid')); ?>
                        </div>
                    <?php endif; ?>

                    <div class="case-content fs-h6">
                        <?php the_content(); ?>
                    </div>
                </div>
            </section>

            <?php if (comments_open() || get_comments_number()) comments_template(); ?>
        <?php endwhile; ?>

        <?php
        $latest_cases = new WP_Query(array(
                'post_type' => 'cases',
                'posts_per_page' => 2,
                'orderby' => 'date',
                'order' => 'DESC',
                'post__not_in' => array(get_the_ID()),
        ));

        if ($latest_cases->have_posts()) : ?>
            <section class="projects" id="cases">
                <div class="container">
                    <div class="projects-top">
                        <div class="title h2">
                            <h2>More projects</h2>
                        </div>
                    </div>

                    <div class="projects-list grid-two">
                        <?php while ($latest_cases->have_posts()) : $latest_cases->the_post(); ?>
                            <?php get_template_part('templates/post', get_post_type()); ?>
                        <?php endwhile; ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    </main>

<?php get_footer();