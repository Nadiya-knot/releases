<?php

define('THEME_VERSION', wp_get_theme()->get('Version'));

//Load template-settings
require get_template_directory() . '/inc/template-settings.php';

//Register widget area.
require get_template_directory() . '/inc/widget-areas.php';

//Enqueue scripts and styles.
require get_template_directory() . '/inc/enqueue-script-style.php';

//Implement the Custom Header feature.
require get_template_directory() . '/inc/custom-header.php';

//Custom template tags for this theme.
require get_template_directory() . '/inc/template-tags.php';

//Functions which enhance the theme by hooking into WordPress.
require get_template_directory() . '/inc/template-functions.php';

//Customizer additions.
require get_template_directory() . '/inc/customizer.php';

//Load helpers funcs
require get_template_directory() . '/inc/helpers.php';

//Load carbon-field compatibility file.
function knot_register_carbon() {
	require get_template_directory() . '/inc/carbon-fields-options/theme-options.php';
    require get_template_directory() . '/inc/carbon-fields-options/metabox.php';
	require get_template_directory() . '/inc/carbon-fields-options/gutenberg/functions.php';
}
add_action( 'carbon_fields_register_fields', 'knot_register_carbon');