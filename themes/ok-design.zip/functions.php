<?php if (!defined('ABSPATH')) exit;

define('THEME_VERSION', wp_get_theme()->get('Version'));
define('THEME_DIR', get_template_directory());
define('THEME_URI', get_template_directory_uri());

//Plugins load
require_once THEME_DIR . '/inc/plugins-load.php';

//Load template-settings
require_once THEME_DIR . '/inc/template-settings.php';

//Enqueue scripts and styles.
require_once THEME_DIR . '/inc/enqueue-script-style.php';

//Functions which enhance the theme by hooking into WordPress.
require_once THEME_DIR . '/inc/template-functions.php';

//Load helpers functions.
require_once THEME_DIR . '/inc/helpers.php';

//Load Carbon Fields plugin files for theme options and Gutenberg blocks
add_action('carbon_fields_register_fields', function () {
	require_once THEME_DIR . '/inc/carbon-fields/gutenberg/block-assets.php';
	require_once THEME_DIR . '/inc/carbon-fields/gutenberg/block-creator.php';
	require_once THEME_DIR . '/inc/carbon-fields/gutenberg/field-button.php';
    require_once THEME_DIR . '/inc/carbon-fields/gutenberg/field-user.php';

	require_once THEME_DIR . '/inc/carbon-fields/theme-options.php';
	require_once THEME_DIR . '/inc/carbon-fields/nav-menu-item.php';
	require_once THEME_DIR . '/inc/carbon-fields/thank.php';


	foreach (glob(THEME_DIR . '/inc/carbon-fields/gutenberg/*/index.php') as $filename) {
		require_once $filename;
	}
});

require_once THEME_DIR . '/inc/KnotContent.php';

require_once THEME_DIR . '/inc/cases-cpt.php';
require_once THEME_DIR . '/inc/svg-upload.php';