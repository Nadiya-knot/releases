<?php if (!defined('ABSPATH')) exit;
function knot_enqueue()
{
    $swiper_css_url = 'https://cdn.jsdelivr.net/npm/swiper@12/swiper-bundle.min.css';
    $swiper_js_url = 'https://cdn.jsdelivr.net/npm/swiper@12/swiper-bundle.min.js';

    wp_enqueue_style('theme-style', get_stylesheet_uri());
    wp_enqueue_style('knot-swiper', $swiper_css_url, array(), THEME_VERSION);

    wp_enqueue_script('jquery');
    wp_enqueue_script('knot-swiper', $swiper_js_url, array(), THEME_VERSION, true);
    wp_enqueue_script('knot-main', THEME_URI . '/front/js/main.min.js', array(), THEME_VERSION, true);
	add_filter('script_loader_tag', function ($tag, $handle, $src) {
	  if ($handle === 'knot-main') {
	    return '<script type="module" src="' . esc_url($src) . '"></script>';
	  }
	  return $tag;
	}, 10, 3);
}

add_action('wp_enqueue_scripts', function () {
    knot_enqueue();
    wp_enqueue_style('knot-main', THEME_URI . '/front/styles/main.min.css', array(), THEME_VERSION);
//	wp_enqueue_style('fancybox', '//cdn.jsdelivr.net/npm/@fancyapps/ui@6.0/dist/fancybox/fancybox.css', array(), '6.0');

//	wp_enqueue_script('fancybox', '//cdn.jsdelivr.net/npm/@fancyapps/ui@6.0/dist/fancybox/fancybox.umd.js', array(), '6.0', true);
});


// Admin style and script
add_action('admin_enqueue_scripts', function () {
    echo '<style>
        .editor-styles-wrapper{position:relative;z-index:1}
        .editor-styles-wrapper p{line-height:inherit!important}
    	.cf-block__preview section {zoom:.7}
        html :where(.wp-block){max-width:100%!important;margin:0!important}
        :root{--bone_size:0px!important}
        section img,section svg{max-width:100%;height:auto;}
        .cf-complex__group-body[hidden]{display:none!important}
        .column-case_id{width: 5% !important}
        @media(min-width: 782px){.interface-complementary-area,.interface-navigable-region.interface-interface-skeleton__sidebar{width: 400px !important;}}
        </style>';

    knot_enqueue();
    wp_enqueue_style('knot-main', THEME_URI . '/front/styles/main-admin.min.css', array(), THEME_VERSION);
    wp_localize_script('knot-main', 'knot', array(
        'is_admin_page' => is_admin() ? true : false
    ));
});