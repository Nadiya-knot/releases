<?php

if (!defined('ABSPATH')) exit;

function allow_svg_upload($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'allow_svg_upload');

function sanitize_svg($file) {
    if ($file['type'] === 'image/svg+xml') {
        $svg_content = file_get_contents($file['tmp_name']);
        // Просте очищення: видаляємо скрипти
        $svg_content = preg_replace('/<script.*?<\/script>/is', '', $svg_content);
        file_put_contents($file['tmp_name'], $svg_content);
    }
    return $file;
}
add_filter('wp_handle_upload_prefilter', 'sanitize_svg');