<?php if (!defined('ABSPATH')) exit;


/*-----------------------------------------------------------------------------------*/
/* Lang */
/*-----------------------------------------------------------------------------------*/

function knot_lang_prefix()
{
    $prefix = '';
    if (!defined('ICL_LANGUAGE_CODE')) {
        return $prefix;
    }
    $prefix = '_' . ICL_LANGUAGE_CODE;
    return $prefix;
}

function knot_crb_theme($crb_id)
{
    $crb_id .= knot_lang_prefix();

    return carbon_get_theme_option($crb_id);
}

function knot_pll($key)
{
    if (function_exists('pll_get_languages')) {
        return pll__($key);
    } else {
        return $key;
    };
}


/*-----------------------------------------------------------------------------------*/
/* Navigation */
/*-----------------------------------------------------------------------------------*/
function knot_menu_exists($location)
{
    return has_nav_menu($location);
}

function knot_menu_name($location)
{
    $locations = get_nav_menu_locations();
    if (isset($locations[$location])) {
        $menu = wp_get_nav_menu_object($locations[$location]);
        return $menu ? $menu->name : '';
    }
    return '';
}


/*-----------------------------------------------------------------------------------*/
/* Button */
/*-----------------------------------------------------------------------------------*/
function knot_button($fields, $class = '')
{
    if (empty($fields['button_text']) || empty($fields['button_type'])) return '';

    $class = $class === '' ? 'button' : 'button ' . $class;
    $class .= (($fields['button_color'] ?? 'default') !== 'default') ? ' button-' . $fields['button_color'] : '';

    $show_arrow = ($fields['button_arrow'] ?? '') === 'show';
    $after = $show_arrow ? '<i class="icon-arrow"></i>' : '';
    $class .= $show_arrow ? ' button-icon' : '';

    $text = esc_html($fields['button_text']) . ' ' . $after;
    $button_type = $fields['button_type'];

    switch ($button_type) {
        case 'link':
            $new_window = ($fields['button_new_window'] ?? '') === true ? ' target="_blank" rel="noopener noreferrer"' : '';
            $link = isset($fields['button_link']) ? esc_url($fields['button_link']) : '#';
            return <<<HTML
                <a href="{$link}" class="{$class}"{$new_window}>{$text}</a>
            HTML;

        case 'page':
            $page = $fields['button_page'][0]['id'] ?? null;
            if ($page) {
                $link = get_permalink($page);
                return <<<HTML
                    <a href="{$link}" class="{$class}">{$text}</a>
                HTML;
            }
            return '';

        case 'download':
            $file = $fields['button_file'] ?? '';
            if ($file) {
                return <<<HTML
                    <a href="{$file}" class="{$class}" download>{$text}</a>
                HTML;
            }
            return '';

        case 'form':
            return <<<HTML
                <button class="{$class}" data-action="open" data-modal="modal-donate">{$text}</button>
            HTML;

        case 'gallery':
            return <<<HTML
                <button class="{$class}" data-open-fancybox>{$text}</button>
            HTML;

        case 'video':
            $video_id = $fields['button_video'] ?? '';

            if ($video_id) {
                $video_url = wp_get_attachment_url($video_id);
                return <<<HTML
                    <a href="{$video_url}" class="{$class}" data-fancybox-video="{$video_id}">{$text}</a>
                HTML;
            }
            return '';

        default:
            return <<<HTML
                <div class="{$class}">{$text}</div>
            HTML;
    }
}

/**
 * Виводить кнопку з Carbon Fields за префіксом
 *
 * @param string|array $button_or_prefix Префікс полів або масив кнопки
 * @param string $button_class Додатковий клас для кнопки
 * @param string|null $wrapper Обгортка
 * @return void
 */
function the_crb_button($button_or_prefix = '', string $button_class = '', string $wrapper = null): void
{
    if (is_array($button_or_prefix)) {
        $button = $button_or_prefix;
    } else {
        $p = $button_or_prefix ? $button_or_prefix . '_' : '';
        $button = [
            'button_text' => knot_crb_theme($p . 'button_text'),
            'button_type' => knot_crb_theme($p . 'button_type'),
            'button_link' => knot_crb_theme($p . 'button_link'),
            'button_new_window' => knot_crb_theme($p . 'button_new_window'),
            'button_icon' => knot_crb_theme($p . 'button_icon'),
            'button_arrow' => knot_crb_theme($p . 'button_arrow'),
            'button_color' => knot_crb_theme($p . 'button_color'),
            'button_file' => knot_crb_theme($p . 'button_file'),
            'button_page' => knot_crb_theme($p . 'button_page'),
            'button_video' => knot_crb_theme($p . 'button_video'),
        ];
    }

    if (($button['button_type'] ?? '') !== 'hide' && !empty($button['button_text'])) {
        if ($wrapper) echo '<div class="' . esc_attr($wrapper) . '">';
        echo knot_button($button, $button_class);
        if ($wrapper) echo '</div>';
    }
}


/*-----------------------------------------------------------------------------------*/
/* Media */
/*-----------------------------------------------------------------------------------*/

function knot_image($image_id = '', $size = 'full', $add_class = '')
{
    $class = '';

    if (!isset($image_id) || $image_id === '' || $image_id === false || $image_id === 0) return;// $image_id = 87;

    if ($add_class != '') $class .= ' ' . $add_class;

    $image_url = wp_get_attachment_image_url($image_id, $size);
    $webp_url = $image_url . '.webp';

    $upload_dir = wp_get_upload_dir();
    $webp_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $webp_url);

    // Отримуємо атрибути зображення
    $image_attributes = wp_get_attachment_image_src($image_id, $size);
    if ($image_attributes) {
        $width = $image_attributes[1];
        $height = $image_attributes[2];
    }

    // Створюємо HTML зображення з data-src замість src
    $image_html = sprintf(
        '<img class="%1$s" src="%2$s" width="%3$s" height="%4$s" alt="%5$s">',
        esc_attr($class),
        esc_url($image_url),
        esc_attr($width),
        esc_attr($height),
        esc_attr(get_post_meta($image_id, '_wp_attachment_image_alt', true))
    );

    if (file_exists($webp_path)) {
        return <<<HTML
            <picture>
                <source src="{$webp_url}" type="image/webp">
                {$image_html}
            </picture>
        HTML;
    } else {
        return $image_html;
    }
}

function knot_video($video_id = '', $add_class = '', $attributes = 'controls preload="metadata"')
{
    $class = 'video-wrapper';

    if (!isset($video_id) || $video_id == '') {
        return '';
    }

    if ($add_class != '') {
        $class .= ' ' . $add_class;
    }

    $video_url = wp_get_attachment_url($video_id);
    $mime_type = get_post_mime_type($video_id);

    $play = knot_image_dir('svg/play');
    return <<<HTML
        <div class="{$class}">
            <video {$attributes}>
                <source src="{$video_url}" type="{$mime_type}">
                Ваш браузер не підтримує відтворення відео.
            </video>
            <button class="video-hide-on-play video-play-btn">{$play}</button>
        </div>
    HTML;
}

function knot_media($media_id = '', $size = 'full', $add_class = '', $attributes = 'controls preload="metadata"')
{
    if (!isset($media_id) || $media_id == '') {
        $media_id = 43;
    }

    $mime_type = get_post_mime_type($media_id);

    if (strpos($mime_type, 'image/') === 0) {
        return knot_image($media_id, $size, $add_class);
    } elseif (strpos($mime_type, 'video/') === 0) {
        return knot_video($media_id, $add_class, $attributes);
    } else {
        return '';
    }
}

function knot_image_dir($name, $format = '.svg', $attr = false)
{
    $path = get_theme_file_path("front/images/$name$format");

    if (!file_exists($path)) return;

    $image_content = file_get_contents($path);

    $image_extension = pathinfo($path, PATHINFO_EXTENSION);

    if ($image_content && strtolower($image_extension) === 'svg') {
        $dom = new DOMDocument();
        $dom->loadXML($image_content);

        $width = $dom->documentElement->getAttribute('width');
        $height = $dom->documentElement->getAttribute('height');
    } elseif ($image_content && strtolower($image_extension) === 'png') {
        list($width, $height) = getimagesize($path);
    } else {
        return;
    }

    // URL для атрибуту src
    $src = get_theme_file_uri("front/images/$name$format");

    return '<img width="' . $width . '" height="' . $height . '" src="' . $src . '"' . ($attr ? ' ' . $attr : '') . '>';
}


/*-----------------------------------------------------------------------------------*/
/* Page link by template and language */
/*-----------------------------------------------------------------------------------*/
function knot_get_links_by_template_and_language($template)
{
    $args = array(
        'post_type' => 'page',
        'meta_key' => '_wp_page_template',
        'meta_value' => $template,
        'posts_per_page' => -1
    );

    if (function_exists('pll_current_language')) $args['lang'] = pll_current_language();

    $query = new WP_Query($args);
    $links = array();

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $links[] = get_permalink();
        }
        wp_reset_postdata();
    }

    return $links;
}


function isArrayEmpty($array)
{
    $exclude_keys = ['button_type'];

    foreach ($array as $key => $value) {
        if (!in_array($key, $exclude_keys) && !empty($value)) {
            return true;
        }
    }

    return false;
}


function format_phone_to_tel(?string $phone): ?string
{
    if ($phone === null) return null;
    // Обрізати пробіли по краях
    $phone = trim($phone);
    if ($phone === '') return null;

    // Замінити ведучі 00 на +
    $phone = preg_replace('/^\s*00/', '+', $phone);

    // Залишити лише цифри та ведучий плюс
    // Якщо плюс є не на початку — прибрати його
    $phone = preg_replace('/(?!^\+)[^\d]+/', '', $phone); // видаляє все, крім цифр і ведучого +
    // Також видалимо зайві плюси, якщо більше одного
    $phone = preg_replace('/\++/', '+', $phone);
    if (strpos($phone, '+') > 0) {
        // плюс не на початку — прибираємо
        $phone = str_replace('+', '', $phone);
    }

    // Якщо лишилися тільки цифри або +цифри — формуємо tel:
    $clean = preg_replace('/[^\d+]/', '', $phone);
    if ($clean === '' || $clean === '+') return null;

    return 'tel:' . $clean;
}