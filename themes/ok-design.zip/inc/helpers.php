<?php if (!defined('ABSPATH')) exit;


if (!function_exists('get_pr')) {
	/**
	 * Debug function print_r
	 *
	 * @param mixed $var
	 * @param boolean $die
	 */
	function get_pr($var, $die = false)
	{
		echo '<pre>';
		print_r($var);
		echo '</pre>';
		if ($die) {
			die();
		}
	}
}
if (!function_exists('get_vd')) {
	/**
	 * Debug function var_dump
	 *
	 * @param mixed $var
	 * @param boolean $die
	 */
	function get_vd($var, $die = false)
	{
		echo '<pre>';
		var_dump($var);
		echo '</pre>';
		if ($die) {
			die();
		}
	}
}
if (!function_exists('get_num_ending')) {
	/**
	 * Declensions of numerals
	 *
	 * @param $number
	 * @param $ending_array
	 *
	 * @return mixed
	 */
	function get_num_ending($number, $ending_array)
	{
		$number = $number % 100;
		if ($number >= 11 && $number <= 19) {
			$ending = $ending_array[2];
		} else {
			$i = $number % 10;
			switch ($i) {
				case (1):
					$ending = $ending_array[0];
					break;
				case (2):
				case (3):
				case (4):
					$ending = $ending_array[1];
					break;
				default:
					$ending = $ending_array[2];
			}
		}

		return $ending;
	}
}

if (!function_exists('field_has_error')) {
	function field_has_error($field_name, $error_fields)
	{
		return !empty($error_fields[$field_name]);
	}
}

if (!function_exists('transliterate')) {
	function transliterate($string)
	{
		$converter = array(
			'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'ґ' => 'g', 'д' => 'd', 'е' => 'e', 'є' => 'ye', 'ж' => 'zh', 'з' => 'z', 'и' => 'y', 'і' => 'i', 'ї' => 'yi', 'й' => 'y',
			'к' => 'k', 'л' => 'l', 'м' => 'm', 'н' => 'n', 'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't', 'у' => 'u', 'ф' => 'f', 'х' => 'kh', 'ц' => 'ts', 'ч' => 'ch',
			'ш' => 'sh', 'щ' => 'shch', 'ь' => '', 'ю' => 'yu', 'я' => 'ya', 'А' => 'A', 'Б' => 'B', 'В' => 'V', 'Г' => 'G', 'Ґ' => 'G', 'Д' => 'D', 'Е' => 'E', 'Є' => 'Ye', 'Ж' => 'Zh',
			'З' => 'Z', 'И' => 'Y', 'І' => 'I', 'Ї' => 'Yi', 'Й' => 'Y', 'К' => 'K', 'Л' => 'L', 'М' => 'M', 'Н' => 'N', 'О' => 'O', 'П' => 'P', 'Р' => 'R', 'С' => 'S', 'Т' => 'T',
			'У' => 'U', 'Ф' => 'F', 'Х' => 'Kh', 'Ц' => 'Ts', 'Ч' => 'Ch', 'Ш' => 'Sh', 'Щ' => 'Shch', 'Ь' => '', 'Ю' => 'Yu', 'Я' => 'Ya'
		);
		$transliterated = strtr($string, $converter);
		$transliterated = preg_replace('/[^a-zA-Z0-9_-]/', '', $transliterated);
		return strtolower($transliterated);
	}
}

if (!function_exists('generate_unique_login')) {
	function generate_unique_login($login_base)
	{
		do {
			$random_suffix = '';
			for ($i = 0; $i < 6; $i++) {
				$random_suffix .= mt_rand(0, 9);
			}

			$login = $login_base . '-' . $random_suffix;
		} while (username_exists($login));
		return $login;
	}
}


if (!function_exists('render_input_field')) {
	/**
	 * Рендерить поле форми через шаблон input-field.php
	 *
	 * @param array $field Параметри поля:
	 *   - name (string) — ім'я поля (обов’язково)
	 *   - label (string) — текст лейбла
	 *   - type (string) — тип input (default: text)
	 *   - tag (string) — тег (input, textarea, select) (default: input)
	 *   - placeholder (string)
	 *   - icon (string)
	 *   - value (mixed)
	 *   - error (string)
	 *   - id (string)
	 *   - options (array) — для select
	 *   - attrs (array) — додаткові атрибути (key => value)
	 *   - show_label (bool) — чи показувати лейбл (default: true)
	 *   - show_icon (bool) — чи показувати іконку (default: true)
	 *   - disabled (bool)
	 */
	function render_input_field(array $field): void
	{
		$defaults = [
			'name' => '',
			'label' => '',
			'type' => 'text',
			'tag' => 'input',
			'placeholder' => '',
			'icon' => '',
			'value' => '',
			'error' => '',
			'id' => '',
			'options' => [],
			'attrs' => [],
			'show_label' => true,
			'show_icon' => true,
			'disabled' => false,
			'aria_attrs' => [],
		];


		$field = array_merge($defaults, $field);

		if (empty($field['id'])) {
			$field['id'] = 'field-' . sanitize_html_class($field['name']);
		}

		extract($field);

		include locate_template('partials/fields/input-field.php');
	}
}

if (!function_exists('prepare_field_params')) {
	function prepare_field_params(array $field, array $old, WP_User $current_user, array $errors_fields = [], array $options = []): array
	{
		$defaults = [
			'show_icon' => true,
			'show_label' => true,
			'disabled' => false,
		];

		$opts = array_merge($defaults, $options);

		$error = $errors_fields[$field['name']] ?? '';
		$value = field_value($field['name'], $old, $current_user);
		$aria_attrs = ['aria-labelledby' => 'label-' . $field['name']];

		if ($error) {
			$aria_attrs['aria-invalid'] = 'true';
			$aria_attrs['aria-describedby'] = 'error-' . $field['name'];
		}

		return [
			'name' => $field['name'],
			'label' => $field['label'] ?? '',
			'type' => $field['type'] ?? 'text',
			'placeholder' => $field['placeholder'] ?? '',
			'icon' => $field['icon'] ?? '',
			'value' => $value,
			'error' => $error,
			'id' => 'field-' . $field['name'],
			'aria_attrs' => $aria_attrs,
			'show_label' => $opts['show_label'],
			'show_icon' => $opts['show_icon'],
			'disabled' => $opts['disabled'],
		];
	}
}



/**
 * Валідація паролю (довжина, букви/цифри і т.д.)
 *
 * @param string $password
 * @return string[] масив помилок
 */
function validate_user_password(string $password): array {
    $errors = [];

    if (empty($password)) {
        $errors[] = 'Пароль є обовʼязковим.';
    } elseif (strlen($password) < 8) {
        $errors[] = 'Пароль повинен містити мінімум 8 символів.';
    } elseif (!preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
        $errors[] = 'Пароль повинен містити хоча б одну букву та цифру.';
    }

    return $errors;
}