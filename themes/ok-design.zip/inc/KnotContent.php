<?php

class KnotContent
{
    private string $defaultTitleClass = 'title';
    private string $defaultTextClass = 'richText';
    private string $defaultWrapperClass = 'content';

    /**
     * Рендерить content з title, text і кнопкою
     * @param string|null $title
     * @param string|null $text
     * @param array|null $button Масив з параметрами кнопки, наприклад:
     *      ['button_type'=>'link','button_text'=>'Take Me Home','button_link'=>home_url()]
     * @param bool $withWrapper Додати wrapper div чи ні
     * @param string $wrapperClass
     * @param string $titleClass
     * @param string $textClass
     * @param string $buttonClass
     * @return string
     */
    public static function renderContent(
        ?string $title = null,
        ?string $text = null,
        ?array $button = null,
        bool $withWrapper = true,
        string $wrapperClass = '',
        string $titleClass = '',
        string $textClass = '',
        string $buttonClass = ''
    ): string {
        $titleHtml = '';
        $textHtml = '';
        $buttonHtml = '';

        if (!empty($title)) {
            $titleHtml = sprintf(
                '<div class="%s">%s</div>',
                esc_attr($titleClass ?: 'title'),
                apply_filters('the_content', $title)
            );
        }

        if (!empty($text)) {
            $textHtml = sprintf(
                '<div class="%s">%s</div>',
                esc_attr($textClass ?: 'richText'),
                apply_filters('the_content', $text)
            );
        }

        if (!empty($button) && function_exists('knot_button')) {
            $buttonHtml = knot_button($button, $buttonClass ?: 'button-green', '');
        }

        if ($titleHtml === '' && $textHtml === '' && $buttonHtml === '') return '';

        if ($withWrapper) {
            $wrapperClass = $wrapperClass !== '' ? 'content ' . $wrapperClass : 'content';
            return sprintf(
                '<div class="%s">%s%s%s</div>',
                esc_attr($wrapperClass),
                $titleHtml,
                $textHtml,
                $buttonHtml
            );
        }

        return $titleHtml . $textHtml . $buttonHtml;
    }
}