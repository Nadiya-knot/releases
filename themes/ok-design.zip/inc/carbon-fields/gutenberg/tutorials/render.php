<?php if (!defined('ABSPATH')) exit;

$block_name = 'tutorials';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="tutorials"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="tutorials-head flex-end-between">
                    <?php echo KnotContent::renderContent(
                            $title,
                            $text,
                            null,
                            true,
                            'tutorials-content',
                            'title h3',
                    ); ?>

                    <?php the_crb_button($fields); ?>
                </div>
                <?php if ($list) : ?>
                    <div class="tutorials-list grid-two">
                        <?php foreach ($list as $item) : ?>
                            <article class="tutorials-li">
                                <div class="tutorials-li__media">
                                    <?php
                                    $posterUrl = isset($item['poster']) ? wp_get_attachment_image_url($item['poster'], 'full') : '';
                                    $attributes = 'preload="metadata"';
                                    if ($posterUrl) {
                                        $attributes .= ' poster="' . $posterUrl . '"';
                                    }

                                    echo knot_media($item['media'], 'full', '', $attributes);
                                    ?>
                                </div>
                                <div class="tutorials-li__content content">
                                    <?php if ($item['name']) : ?>
                                        <a class="title h4">
                                            <?php echo apply_filters('the_content', $item['name']); ?>
                                        </a>
                                    <?php endif; ?>
                                    <?php if ($item['text']) : ?>
                                        <div class="richText">
                                            <?php echo apply_filters('the_content', $item['text']); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <?php
    });
};