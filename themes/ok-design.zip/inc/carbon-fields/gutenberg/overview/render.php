<?php if (!defined('ABSPATH')) exit;

$block_name = 'overview';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);

        $decoration = $decoration ?? '';
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        $title = $title ?? '';
        $text = $text ?? '';
        $reverse = $reverse ?? false;
        $background = $background ?? false;
        $numbers = $numbers ?? [];
        $media = $media ?? null;

        ?>
        <section class="overview"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <?php if ($decoration !== 'none' && $decoration) : ?>
                <div class="overview-decoration-<?php echo $decoration; ?> decoration">
                    <?php switch ($decoration) {
                        case 'one':
                            echo knot_image_dir('svg/dec/over-1');
                            break;
                        case 'two':
                            echo knot_image_dir('svg/dec/over-2');
                            echo knot_image_dir('svg/dec/over-3', '.svg', 'data-rotate');
                            break;
                        case 'three':
                            echo knot_image_dir('svg/dec/over-3', '.svg', 'data-rotate');
                            break;
                        default:
                            break;
                    } ?>
                </div>
            <?php endif; ?>
            <div class="container">
                <div class="overview-net flex-center-between<?php echo $reverse ? ' overview-reverse' : ''; ?><?php echo $background ? ' overview-background' : ''; ?>">
                    <div class="overview-content">
                        <div class="content">
                            <?php echo KnotContent::renderContent(
                                    $title,
                                    $text,
                                    null,
                                    false,
                                    '',
                                    'title h3',
                            ); ?>

                            <div class="overview-button flex-center-start">
                                <?php the_crb_button($fields); ?>
                                <?php the_crb_button([
                                        'button_text' => $two_button_text ?? '',
                                        'button_type' => $two_button_type ?? '',
                                        'button_link' => $two_button_link ?? '',
                                        'button_new_window' => $two_button_new_window ?? '',
                                        'button_icon' => $two_button_icon ?? '',
                                        'button_arrow' => $two_button_arrow ?? '',
                                        'button_color' => $two_button_color ?? '',
                                        'button_file' => $two_button_file ?? '',
                                        'button_page' => $two_button_page ?? '',
                                        'button_video' => $two_button_video ?? '',
                                ]); ?>
                            </div>
                        </div>

                        <?php if (!empty($numbers)) : ?>
                            <ul class="numbers">
                                <?php foreach ($numbers as $number) : ?>
                                    <li class="number">
                                        <span class="title h3">
                                            <?php echo $number['number_before'] ?? ''; ?>
                                            <span data-number="<?php echo $number['number'] ?? 0; ?>">0</span>
                                            <?php echo $number['number_after'] ?? ''; ?>
                                        </span>
                                        <?php echo apply_filters('the_content', $number['text'] ?? ''); ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>

                    <?php if ($media) : ?>
                        <div class="overview-media<?php echo $background ? ' overview-media-small' : ''; ?>">
                            <?php
                            $posterUrl = isset($poster) ? wp_get_attachment_image_url($poster, 'full') : '';
                            $attributes = 'preload="metadata"';
                            if ($posterUrl) {
                                $attributes .= ' poster="' . $posterUrl . '"';
                            }

                            echo knot_media($media, 'full', '', $attributes);
                            ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
    });
};