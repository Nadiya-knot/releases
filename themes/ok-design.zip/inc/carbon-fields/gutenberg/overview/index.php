<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

$block_name = 'overview';

crb_register_block_assets($block_name);

crb_create_block(
    $block_name,
    function () use ($block_name) {
        return array_merge(
            array_filter([crb_preview_field($block_name)]),
            [Field::make('rich_text', 'title', __('Title'))],
            [Field::make('rich_text', 'text', __('Text'))],
            [Field::make('checkbox', 'reverse', __('Reverse'))],
            [Field::make('checkbox', 'background', __('Background'))],
            [Field::make('image', 'media', __('Media'))->set_type(array('image', 'video'))->set_width(50)],
            [Field::make('image', 'poster', __('Video poster'))->set_type(array('image'))->set_width(50)
                ->set_help_text('Works only with mp4 format')],
        );
    },
    require __DIR__ . '/render.php',
    function () {
        return [
            __('Decoration') => [
                Field::make('radio', 'decoration', '')->add_options([
                    'none' => __('None'),
                    'one' => __('One'),
                    'two' => __('Two'),
                    'three' => __('Three'),
                ])->set_default_value('none'),
            ],
            __('Button') => crb_button_fields(),
            __('Button 2') => crb_button_fields('two'),
            __('Numbers') => [
                Field::make('complex', 'numbers', '')->set_collapsed(true)
                    ->add_fields([
                        Field::make('rich_text', 'text', __('Text')),
                        Field::make('text', 'number_before', __('Before'))->set_width(30),
                        Field::make('text', 'number', __('Number'))
                            ->set_attribute('type', 'number')
                            ->set_attribute('step', '1')
                            ->set_width(40),
                        Field::make('text', 'number_after', __('After'))->set_width(30),
                    ])
                    ->set_header_template('
						<% if (text) { %>
							<%- _.unescape(text).replace(/<[^>]*>/g, "") %>
						<% } %>
					')
            ]
        ];
    }
);