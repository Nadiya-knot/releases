<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

/**
 * Повертає масив полів для кнопки
 *
 * @param string $prefix Префікс для унікальних ключів (опціонально)
 * @param bool $preview Чи додавати прев’ю заголовок
 * @return array
 */
function crb_button_fields(string $prefix = '', bool $preview = false): array
{
    $p = $prefix ? $prefix . '_' : '';
    $fields = [];

    if ($preview) {
        $fields[] = Field::make('html', $p . 'button_preview', __('Button'))
            ->set_html('<div class="fs-h5">Button</div>');
    }

    $fields[] = Field::make('text', $p . 'button_text', __('Text'));
    $fields[] = Field::make('radio', $p . 'button_type', __('Type'))
        ->add_options([
            'link' => __('Link'),
//            'form' => __('Form'),
            'page' => __('Page'),
            'download' => __('Download'),
            'hide' => __('Hide'),
        ])
        ->set_default_value('hide');
    $fields[] = Field::make('association', $p . 'button_page', __('Page'))
        ->set_conditional_logic([
            [
                'field' => $p . 'button_type',
                'value' => 'page',
            ]
        ])
        ->set_types(array(
            array(
                'type' => 'post',
                'post_type' => 'page',
            ),
            array(
                'type' => 'post',
                'post_type' => 'post',
            ),
        ))
        ->set_max(1);
    $fields[] = Field::make('text', $p . 'button_link', __('Link'))
        ->set_conditional_logic([
            [
                'field' => $p . 'button_type',
                'value' => 'link',
            ]
        ]);
    $fields[] = Field::make('checkbox', $p . 'button_new_window', __('Open in new window'))
        ->set_conditional_logic([
            [
                'field' => $p . 'button_type',
                'value' => 'link',
            ]
        ]);
    $fields[] = Field::make('file', $p . 'button_file', __('File'))
        ->set_conditional_logic([
            [
                'field' => $p . 'button_type',
                'value' => 'download',
            ]
        ])
        ->set_value_type('url');


    return $fields;
}