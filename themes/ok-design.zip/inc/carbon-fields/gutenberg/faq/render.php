<?php if (!defined('ABSPATH')) exit;

$block_name = 'faq';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="faq"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="faq-net flex-start-between">
                    <div class="faq-top content">
                        <?php if ($label) : ?>
                            <div class="label">
                                <?php echo apply_filters('the_content', $label); ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($title) : ?>
                            <div class="title h2">
                                <?php echo apply_filters('the_content', $title); ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($list) : ?>
                        <ul class="faq-list" itemscope itemtype="https://schema.org/FAQPage">
                            <?php foreach ($list as $item) : ?>
                                <?php if (!$item['title'] && !$item['text']) continue; ?>
                                <li class="faq-li" itemscope itemprop="mainEntity"
                                    itemtype="https://schema.org/Question">
                                    <h3>
                                        <button class="faq-trigger title h5" aria-expanded="false" itemprop="name">
                                            <?php echo $item['title']; ?>
                                        </button>
                                    </h3>

                                    <div class="faq-content" itemscope itemprop="acceptedAnswer"
                                         itemtype="https://schema.org/Answer">
                                        <div class="richText" itemprop="text">
                                            <?php echo apply_filters('the_content', $item['text']); ?>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
    });
};