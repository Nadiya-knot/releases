<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

$block_name = 'faq';

crb_register_block_assets($block_name);

crb_create_block(
    $block_name,
    function () use ($block_name) {
        return array_merge(
            array_filter([crb_preview_field($block_name)]),
            [Field::make('rich_text', 'label', __('Label'))],
            [Field::make('rich_text', 'title', __('Title'))],
        );
    },
    require __DIR__ . '/render.php',
    function () {
        return [
            __('FAQs') => [
                Field::make('complex', 'list', '')->set_collapsed(true)
                    ->add_fields([
                        Field::make('rich_text', 'title', __('Title')),
                        Field::make('rich_text', 'text', __('Text')),
                    ])
                    ->set_header_template('
						<% if (title) { %>
							<%- _.unescape(title).replace(/<[^>]*>/g, "") %>
						<% } %>
					'),
            ]
        ];
    }
);