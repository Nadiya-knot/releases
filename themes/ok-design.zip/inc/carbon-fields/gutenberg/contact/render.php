<?php if (!defined('ABSPATH')) exit;

$block_name = 'contact';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="contact"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="contact-decoration decoration">
                <?php echo knot_image_dir('svg/dec/over-3', '.svg', 'data-rotate'); ?>
            </div>
            <div class="container">
                <div class="contact-net flex">
                    <div class="contact-info content">
                        <?php echo KnotContent::renderContent(
                                $title,
                                $text,
                                null,
                                true,
                                'contact-content content',
                                'title h1',
                        ); ?>

                        <?php if ($list) : ?>
                            <div class="contact-list">
                                <?php foreach ($list as $item) : ?>
                                    <div class="contact-li">
                                        <?php if ($item['icon']) : ?>
                                            <div class="contact-li-icon-wrapper">
                                                <?php $image = wp_get_attachment_image_url($item['icon']); ?>
                                                <div class="contact-li-icon"
                                                     style="mask-image: url('<?php echo $image; ?>')"></div>
                                            </div>
                                        <?php endif; ?>

                                        <div class="contact-li-info">
                                            <?php if ($item['name']) : ?>
                                                <div class="contact-li-label">
                                                    <?php echo apply_filters('the_content', $item['name']); ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if ($item['text']) : ?>
                                                <div class="contact-li-text">
                                                    <?php echo apply_filters('the_content', $item['text']); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($shortcode)) : ?>
                        <div class="contact-form">
                            <div class="contact-decoration-two decoration">
                                <?php echo knot_image_dir('svg/dec/contact'); ?>
                            </div>
                            <?php echo do_shortcode($shortcode); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
    });
};