<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

$block_name = 'contact';

crb_register_block_assets($block_name);

crb_create_block(
    $block_name,
    function () use ($block_name) {
        return array_merge(
            array_filter([crb_preview_field($block_name)]),
            [Field::make('rich_text', 'title', __('Title'))],
            [Field::make('rich_text', 'text', __('Text'))],
            [Field::make('text', 'shortcode', __('Shortcode'))],
        );
    },
    require __DIR__ . '/render.php',
    function () {
        return [
            __('List') => [
                Field::make('complex', 'list', '')->set_collapsed(true)
                    ->add_fields([
                        Field::make('image', 'icon', __('Icon'))->set_type(array('image')),
                        Field::make('rich_text', 'name', __('Name')),
                        Field::make('rich_text', 'text', __('Text'))
                            ->set_help_text('
                                <ul>
                                    <li><code onclick="copyToClipboard(\'tel:\')">tel:</code> - phone url</li>
                                    <li><code onclick="copyToClipboard(\'mailto:\')">mailto:</code> - email url</li>
                                </ul>
                            '),
                    ])
                    ->set_header_template('
						<% if (name) { %>
							<%- _.unescape(name).replace(/<[^>]*>/g, "") %>
						<% } %>
					'),
            ]
        ];
    }
);