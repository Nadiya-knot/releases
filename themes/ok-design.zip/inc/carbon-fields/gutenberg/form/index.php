<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

$block_name = 'form';

crb_register_block_assets($block_name);

crb_create_block(
    $block_name,
    function () use ($block_name) {
        return array_merge(
            array_filter([crb_preview_field($block_name)]),
            [Field::make('rich_text', 'title', __('Title'))],
            [Field::make('rich_text', 'text', __('Text'))],
        );
    },
    require __DIR__ . '/render.php',
    function () {
        return [
            __('Review') => [
                Field::make('rich_text', 'review_text', __('Text')),
                Field::make('radio', 'review_stars', __('Stars'))->add_options([
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                ]),
                ...crb_user_fields('', true),
            ],
            __('Send a Message') => [
                Field::make('text', 'shortcode', __('Shortcode')),
            ],
            __('Book a Call') => [
                Field::make('textarea', 'ember', __('Ember code')),
            ],
        ];
    }
);