<?php if (!defined('ABSPATH')) exit;

$block_name = 'form';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="form"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="form-net">
                    <div class="form-left">
                        <?php echo KnotContent::renderContent($title, $text, null, true, 'content', 'title h2'); ?>

                        <?php if ($review_text) : ?>
                            <div class="review-item">
                                <div class="content">
                                    <div class="review-item-head">
                                        <?php if (!empty($review_stars)) : ?>
                                            <div class="review-item-stars">
                                                <?php
                                                $stars = (int)$review_stars;
                                                for ($i = 1; $i <= 5; $i++) {
                                                    echo '<span' . ($i <= $stars ? ' class="active"' : '') . '></span>';
                                                }
                                                ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="richText">
                                        <?php echo apply_filters('the_content', $review_text); ?>
                                    </div>
                                </div>

                                <?php crb_render_user($fields); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-right">
                        <div class="form-tabs">
                            <?php if ($shortcode) : ?>
                                <button class="active"><?php echo knot_image_dir('svg/message'); ?>Send a Message</button>
                            <?php endif; ?>
                            <?php if ($ember) : ?>
                                <button<?php if (!$shortcode) echo ' class="active"' ?>><?php echo knot_image_dir('svg/call'); ?>
                                    Book a Call
                                </button>
                            <?php endif; ?>
                        </div>
                        <div class="form-tab-content">
                            <?php if ($shortcode) : ?>
                                <div class="form-tab-wpcf7"><?php echo do_shortcode($shortcode); ?></div>
                            <?php endif; ?>

                            <?php if ($ember) : ?>
                                <div class="form-tab-book"<?php if ($shortcode) echo ' style="display: none;"'; ?>>
                                    <?php echo $ember; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php
    });
};