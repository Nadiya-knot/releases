<?php if (!defined('ABSPATH')) exit;

$block_name = 'what';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="what"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <?php echo KnotContent::renderContent(
                        $title,
                        $text,
                        null,
                        true,
                        'what-top content content-center',
                        'title h1',
                ); ?>

                <?php if ($list) : ?>
                    <div class="what-list content">
                        <?php foreach ($list as $item) : ?>
                            <div class="what-li flex-center-between">
                                <div class="what-content">
                                    <div class="content">
                                        <?php echo KnotContent::renderContent(
                                                $item['title'],
                                                $item['text'],
                                                null,
                                                false,
                                                '',
                                                'title h2',
                                        ); ?>

                                        <?php the_crb_button($item); ?>
                                    </div>

                                    <?php if ($item['tabs']) : ?>
                                        <ul class="tabs">
                                            <?php foreach ($item['tabs'] as $tab) echo "<li>{$tab['name']}</li>"; ?>
                                        </ul>
                                    <?php endif; ?>
                                </div>
                                <div class="what-image">
                                    <?php echo knot_image($item['image']); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <?php
    });
};