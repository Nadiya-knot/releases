<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

$block_name = 'what';

crb_register_block_assets($block_name);

crb_create_block(
    $block_name,
    function () use ($block_name) {
        return array_merge(
            array_filter([crb_preview_field($block_name)]),
            [Field::make('rich_text', 'title', __('Title'))],
            [Field::make('rich_text', 'text', __('Text'))],
        );
    },
    require __DIR__ . '/render.php',
    function () {
        return [
            __('List') => [
                Field::make('complex', 'list', '')->set_collapsed(true)
                    ->add_fields([
                        Field::make('rich_text', 'title', __('Title')),
                        Field::make('rich_text', 'text', __('Text')),
                        Field::make('image', 'image', __('Image'))->set_type(array('image')),
                        ...crb_button_fields('', true),
                        Field::make('complex', 'tabs', __('Tabs'))->set_collapsed(true)
                            ->add_fields([
                                Field::make('text', 'name', __('Name')),
                            ])
                            ->set_header_template('
                                <% if (name) { %>
                                    <%- _.unescape(name).replace(/<[^>]*>/g, "") %>
                                <% } %>
                            '),
                    ])
                    ->set_header_template('
						<% if (title) { %>
							<%- _.unescape(title).replace(/<[^>]*>/g, "") %>
						<% } %>
					'),
            ]
        ];
    }
);