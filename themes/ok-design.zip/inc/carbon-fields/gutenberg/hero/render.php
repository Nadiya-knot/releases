<?php if (!defined('ABSPATH')) exit;

$block_name = 'hero';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);

        $decoration = $decoration ?? '';
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        $title = $title ?? '';
        $text = $text ?? '';
        $image_left = $image_left ?? '';
        $image_right = $image_right ?? '';
        $gallery = $gallery ?? [];

        ?>
        <section class="hero"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <?php if ($decoration !== 'none' && $decoration) : ?>
                <div class="hero-decoration-<?php echo $decoration; ?> decoration">
                    <?php switch ($decoration) {
                        case 'one':
                            echo knot_image_dir('svg/dec/over-3', '.svg', 'data-rotate');
                            echo knot_image_dir('svg/dec/hero-1');
                            break;
                        case 'two':
                            echo knot_image_dir('svg/dec/hero-2', '.svg', 'data-rotate');
                            echo knot_image_dir('svg/dec/hero-3');
                            break;
                        default:
                            break;
                    } ?>
                </div>
            <?php endif; ?>

            <div class="container">
                <div class="hero-content content">
                    <?php echo KnotContent::renderContent(
                            $title,
                            $text,
                            null,
                            false,
                            '',
                            'title h1',
                    ); ?>

                    <div class="hero-button flex-center-center">
                        <?php the_crb_button($fields); ?>
                        <?php the_crb_button([
                                'button_text' => $two_button_text ?? '',
                                'button_type' => $two_button_type ?? '',
                                'button_link' => $two_button_link ?? '',
                                'button_new_window' => $two_button_new_window ?? '',
                                'button_icon' => $two_button_icon ?? '',
                                'button_arrow' => $two_button_arrow ?? '',
                                'button_color' => $two_button_color ?? '',
                                'button_file' => $two_button_file ?? '',
                                'button_page' => $two_button_page ?? '',
                                'button_video' => $two_button_video ?? '',
                        ]); ?>
                    </div>
                </div>

                <?php if ($image_left) : ?>
                    <div class="hero-dec-one">
                        <?php echo knot_image($image_left); ?>
                    </div>
                <?php endif; ?>

                <?php if ($image_right) : ?>
                    <div class="hero-dec-two">
                        <?php echo knot_image($image_right); ?>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($gallery) : ?>
                <div class="home-images-wrapper">
                    <div class="home-images">
                        <?php foreach ($gallery as $key => $image_id) : ?>
                            <div class="home-image">
                                <?php echo knot_image($image_id); ?>
                            </div>
                            <?php if ($key > 2) break; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </section>
        <?php
    });
};