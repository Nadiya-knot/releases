class HomeImages {
    constructor(selector = '.home-image') {
        this.images = document.querySelectorAll(selector);
        this.angles = [-15, -5, 5, 15];
        this.yOffsets = [100, 10, 10, 100];

        this.init();
    }

    init() {
        window.addEventListener('load', () => {
            this.centerImagesInstant();

            setTimeout(() => {
                this.spreadImages().then(() => {
                    // підключаємо паралакс після завершення анімації
                    this.addCursorParallax();
                });
            }, 100);
        });
    }

    centerImagesInstant() {
        this.images.forEach(img => {
            img.style.transition = 'none';

            const parent = img.parentElement;
            const parentRect = parent.getBoundingClientRect();
            const rect = img.getBoundingClientRect();

            // центрування відносно батьківського елемента
            const centerX = (parentRect.width / 2) - (rect.left - parentRect.left + rect.width / 2);
            const centerY = (parentRect.height / 2) - (rect.top - parentRect.top + rect.height / 2);

            img.dataset.baseX = centerX;
            img.dataset.baseY = centerY;

            img.style.transform = `translate(${centerX}px, ${centerY}px)`;
            img.style.opacity = '1';
        });
    }

    spreadImages() {
        return new Promise(resolve => {
            let completed = 0;
            this.images.forEach((img, index) => {
                img.style.display = 'block';
                img.style.opacity = '1';
                img.style.transition = 'transform 1s ease, opacity 1s ease';

                const rotate = this.angles[index] || 0;
                const translateY = this.yOffsets[index] || 0;
                img.dataset.baseRotate = rotate;
                img.dataset.baseY = translateY;

                img.style.transform = `translate(0, ${translateY}px) rotate(${rotate}deg)`;

                img.addEventListener('transitionend', function handler(e) {
                    if (e.propertyName === 'transform') {
                        completed++;
                        img.removeEventListener('transitionend', handler);
                        if (completed === document.querySelectorAll('.home-image').length) {
                            resolve();
                        }
                    }
                });
            });
        });
    }

    addCursorParallax() {
        window.addEventListener('mousemove', (e) => {
            const centerX = window.innerWidth / 2;
            const deltaX = (e.clientX - centerX) / centerX; // від -1 до 1

            this.images.forEach((img) => {
                const baseRotate = parseFloat(img.dataset.baseRotate) || 0;
                const baseY = parseFloat(img.dataset.baseY) || 0;

                // додаємо нахил за курсором (макс ±5 градусів)
                const cursorRotate = deltaX * 5;

                // без transition для миттєвої реакції
                img.style.transition = 'none';
                img.style.transform = `translate(0, ${baseY}px) rotate(${baseRotate + cursorRotate}deg)`;
            });
        });
    }
}

new HomeImages('.home-image');