<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

$block_name = 'hero';

crb_register_block_assets($block_name);

crb_create_block(
    $block_name,
    function () use ($block_name) {
        return array_merge(
            array_filter([crb_preview_field($block_name)]),
            [Field::make('rich_text', 'title', __('Title'))],
            [Field::make('rich_text', 'text', __('Text'))],
            [Field::make('media_gallery', 'gallery', __('Gallery'))],
        );
    },
    require __DIR__ . '/render.php',
    function () {
        return [
            __('Decoration') => [
                Field::make('radio', 'decoration', '')->add_options([
                    'none' => __('None'),
                    'one' => __('One'),
                    'two' => __('Two'),
                ])->set_default_value('none'),
            ],
            __('Button') => crb_button_fields(),
            __('Button 2') => crb_button_fields('two'),
            __('Images') => [
              Field::make('image', 'image_left', __('Image Left'))->set_width(50),
              Field::make('image', 'image_right', __('Image Right'))->set_width(50),
            ],
        ];
    }
);