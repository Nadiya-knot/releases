<?php if (!defined('ABSPATH')) exit;

$block_name = 'team';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="team"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <?php echo KnotContent::renderContent($title, $text, null, true, 'team-top content content-center', 'title h2'); ?>

                <?php if ($list) : ?>
                    <div class="team-list grid-two">
                        <?php foreach ($list as $item) : ?>
                            <div class="team-li">
                                <div class="team-image">
                                    <?php echo knot_image($item['image']); ?>
                                </div>

                                <div class="team-info content">
                                    <div>
                                        <?php if ($item['name']) : ?>
                                            <div class="title">
                                                <?php echo apply_filters('the_content', $item['name']); ?>
                                            </div>
                                        <?php endif; ?>

                                        <?php if ($item['position']) echo "<p>{$item['position']}</p>"; ?>
                                    </div>

                                    <?php if ($item['text']) : ?>
                                        <div class="richText">
                                            <?php echo apply_filters('the_content', $item['text']); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <?php
    });
};