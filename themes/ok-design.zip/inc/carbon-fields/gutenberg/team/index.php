<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

$block_name = 'team';

crb_register_block_assets($block_name);

crb_create_block(
    $block_name,
    function () use ($block_name) {
        return array_merge(
            array_filter([crb_preview_field($block_name)]),
            [Field::make('rich_text', 'title', __('Title'))],
            [Field::make('rich_text', 'text', __('Text'))],
        );
    },
    require __DIR__ . '/render.php',
    function () {
        return [
            __('Team') => [
                Field::make('complex', 'list', '')->set_collapsed(true)
                    ->add_fields([
                        Field::make('image', 'image', __('Image'))->set_type(array('image')),
                        Field::make('rich_text', 'name', __('Name')),
                        Field::make('text', 'position', __('Position')),
                        Field::make('rich_text', 'text', __('Text')),
                    ])
                    ->set_header_template('
						<% if (name) { %>
							<%- _.unescape(name).replace(/<[^>]*>/g, "") %>
						<% } %>
					'),
            ]
        ];
    }
);