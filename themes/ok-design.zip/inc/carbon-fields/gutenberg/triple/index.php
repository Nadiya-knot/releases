<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

$block_name = 'triple';

crb_register_block_assets($block_name);

crb_create_block(
    $block_name,
    function () use ($block_name) {
        return array_merge(
            array_filter([crb_preview_field($block_name)]),
            [Field::make('rich_text', 'title', __('Title'))],
        );
    },
    require __DIR__ . '/render.php',
    function () {
        return [
            __('List') => [
                Field::make('complex', 'list', '')->set_collapsed(true)
                    ->add_fields([
                        Field::make('radio', 'type', __('Type'))->add_options([
                            'image' => __('Image'),
                            'outline' => __('Outline'),
                            'background' => __('Background'),
                        ])->set_default_value('outline'),
                        Field::make('image', 'image', __('Image'))->set_type(array('image')),
                        Field::make('rich_text', 'title', __('Title')),
                        Field::make('rich_text', 'text', __('Text')),
                        ...crb_button_fields(),
                    ])
                    ->set_header_template('
						<% if (title) { %>
							<%- _.unescape(title).replace(/<[^>]*>/g, "") %>
						<% } %>
					'),
            ]
        ];
    }
);