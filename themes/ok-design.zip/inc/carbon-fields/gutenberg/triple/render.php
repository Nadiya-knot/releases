<?php if (!defined('ABSPATH')) exit;

$block_name = 'triple';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="triple"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="triple-decoration decoration">
                <?php echo knot_image_dir('svg/dec/triple'); ?>
            </div>
            <div class="container">
                <?php if ($title) : ?>
                    <div class="triple-title title h3">
                        <?php echo apply_filters('the_content', $title); ?>
                    </div>
                <?php endif; ?>

                <?php if ($list) : ?>
                    <div class="triple-net grid-three">
                        <?php foreach ($list as $item) : ?>
                            <?php
                            $class = match ($item['type']) {
                                'background' => 'triple-li triple-li__bg content',
                                'outline' => 'triple-li triple-li__outline content',
                                default => 'triple-li',
                            };
                            ?>
                            <div class="<?php echo $class; ?>">
                                <?php if ($item['type'] !== 'image') : ?>
                                    <div class="triple-li__dec">
                                        <?php echo knot_image_dir('svg/t' . ($item['type'] === 'bg' ? '2' : '1')); ?>
                                    </div>

                                    <div class="triple-li__content content">
                                        <?php if ($item['image']) : ?>
                                            <div class="triple-li__icon">
                                                <?php echo knot_image($item['image']); ?>
                                            </div>
                                        <?php endif; ?>

                                        <?php echo KnotContent::renderContent(
                                                $item['title'],
                                                $item['text'],
                                                null,
                                                true,
                                                '',
                                                'title h5',
                                        ); ?>
                                    </div>
                                    <?php the_crb_button($item, '', 'triple-li__button'); ?>
                                <?php else : ?>
                                    <div class="triple-li__image">
                                        <?php echo knot_image($item['image']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <?php
    });
};