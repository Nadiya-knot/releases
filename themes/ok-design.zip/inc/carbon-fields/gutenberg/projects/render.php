<?php if (!defined('ABSPATH')) exit;

$block_name = 'projects';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="projects"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <?php echo KnotContent::renderContent(
                        $title,
                        $text,
                        null,
                        true,
                        'projects-top content content-center',
                        'title h2',
                ); ?>

                <?php
                $cases_query = new WP_Query(array(
                        'post_type' => 'cases',
                        'posts_per_page' => 4
                ));
                ?>
                <?php if ($cases_query->have_posts()) : ?>
                    <div class="projects-list grid-two">
                        <?php while ($cases_query->have_posts()) : $cases_query->the_post(); ?>
                            <?php get_template_part('templates/post', get_post_type()); ?>
                        <?php endwhile; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <?php
    });
};