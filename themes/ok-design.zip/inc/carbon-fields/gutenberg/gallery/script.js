document.addEventListener('DOMContentLoaded', () => {
    const galleries = document.querySelectorAll('.gallery');

    galleries.forEach((gallery, index) => {
        const items = gallery.querySelectorAll('[data-fancybox]');
        items.forEach(item => {
            item.dataset.fancybox = `gallery-${index}`; // унікальна група
        });

        Fancybox.bind(`[data-fancybox="gallery-${index}"]`, {
            on: {
                close: (fancybox, slide) => {
                    const swiperEl = gallery.querySelector('.gallery-slider.swiper-initialized');
                    const swiper = swiperEl?.swiper;

                    if (swiper) {
                        swiper.destroy(true, true);
                        window.gallerySwiper(); // твоя функція ініціалізації Swiper
                    }
                },
            },
        });

        // Кнопка "Відкрити перше фото"
        const openBtn = gallery.querySelector('[data-open-fancybox]');
        if (openBtn && items.length > 0) {
            openBtn.addEventListener('click', () => {
                const galleryItems = Array.from(items).map(item => ({
                    src: item.getAttribute('href') || item.dataset.src,
                    caption: item.dataset.caption || '',
                    thumbSrc: item.dataset.thumb || '',
                }));

                Fancybox.show(galleryItems, {
                    group: `gallery-${index}`,
                });
            });
        }
    });
});