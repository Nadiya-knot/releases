<?php if (!defined('ABSPATH')) exit;

$block_name = 'gallery';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="gallery"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="gallery-wrapper">
                    <div class="gallery-head flex-end-between">
                        <?php echo KnotContent::renderContent(
                                $title,
                                $text,
                                null,
                                true,
                                'gallery-content',
                                'title h3',
                        ); ?>

                        <div class="gallery-button flex-center-between">
                            <?php the_crb_button($fields); ?>
                            <?php the_crb_button([
                                    'button_text' => $two_button_text ?? '',
                                    'button_type' => $two_button_type ?? '',
                                    'button_link' => $two_button_link ?? '',
                                    'button_new_window' => $two_button_new_window ?? '',
                                    'button_icon' => $two_button_icon ?? '',
                                    'button_arrow' => $two_button_arrow ?? '',
                                    'button_color' => $two_button_color ?? '',
                                    'button_file' => $two_button_file ?? '',
                                    'button_page' => $two_button_page ?? '',
                                    'button_video' => $two_button_video ?? '',
                            ]); ?>
                        </div>
                    </div>

                    <?php if ($gallery) : ?>
                        <div class="gallery-slider swiper">
                            <div class="swiper-gradient"></div>
                            <div class="swiper-wrapper">
                                <?php foreach ($gallery as $image_id) : ?>
                                    <?php $image_url = wp_get_attachment_image_url($image_id, 'full'); ?>
                                    <div class="swiper-slide">
                                        <a href="<?php echo $image_url; ?>"
                                           data-fancybox><?php echo knot_image($image_id); ?></a>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
    });
};