<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

/**
 * Повертає масив полів для кнопки
 *
 * @param string $prefix Префікс для унікальних ключів (опціонально)
 * @param bool $preview Чи додавати прев’ю заголовок
 * @return array
 */
function crb_user_fields(string $prefix = '', bool $preview = false): array
{
    $p = $prefix ? $prefix . '_' : '';
    $fields = [];

    if ($preview) {
        $fields[] = Field::make('html', $p . 'user_preview', __('User'))
                ->set_html('<div class="fs-h5">User</div>');
    }

    $fields[] = Field::make('image', $p . 'user_ava', __('Avatar'))->set_type(array('image'));
    $fields[] = Field::make('text', $p . 'user_name', __('Name'));
    $fields[] = Field::make('text', $p . 'user_label', __('Label'));

    return $fields;
}

function crb_render_user(array $user_data, string $prefix = '')
{
    $p = $prefix ? $prefix . '_' : '';

    $avatar = !empty($user_data[$p . 'user_ava']) ? $user_data[$p . 'user_ava'] : '';
    $name = !empty($user_data[$p . 'user_name']) ? $user_data[$p . 'user_name'] : '';
    $label = !empty($user_data[$p . 'user_label']) ? $user_data[$p . 'user_label'] : '';

    ?>
    <div class="user">
        <div class="user-avatar">
            <?php echo knot_image($avatar); ?>
        </div>
        <div class="user-content">
            <?php if (!empty($name)) : ?>
                <div class="user-name fs-h5 fw-medium">
                    <p><?php echo esc_html($name); ?></p>
                </div>
            <?php endif; ?>
            <?php if (!empty($label)) : ?>
                <div class="user-label">
                    <p><?php echo esc_html($label); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}