<?php if (!defined('ABSPATH')) exit;

$block_name = 'how';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="how"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="how-top flex-end-between">
                    <?php echo KnotContent::renderContent($title, $text, null, true, 'content', 'title h2'); ?>

                    <div class="swiper-button">
                        <button class="swiper-button-prev"></button>
                        <button class="swiper-button-next"></button>
                    </div>
                </div>
                <?php if ($list) : ?>
                    <div class="how-list swiper">
                        <div class="swiper-wrapper">
                            <?php foreach ($list as $item) : ?>
                                <div class="swiper-slide how-item">
                                    <?php echo KnotContent::renderContent($item['title'], $item['text'], null, true, 'content', 'title h4'); ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <?php
    });
};