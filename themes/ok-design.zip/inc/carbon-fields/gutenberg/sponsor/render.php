<?php if (!defined('ABSPATH')) exit;

$block_name = 'sponsor';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="sponsor"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="sponsor-head flex-end-between">
                    <?php echo KnotContent::renderContent(
                            $title,
                            $text,
                            null,
                            true,
                            'sponsor-content content',
                            'title h3',
                    ); ?>

                    <div class="swiper-button">
                        <div class="swiper-button-prev button button-outline button-only-icon">
                            <i class="icon-arrow-next"></i>
                        </div>
                        <div class="swiper-button-next button button-outline button-only-icon">
                            <i class="icon-arrow-next"></i>
                        </div>
                    </div>
                </div>

                <?php if ($list) : ?>
                    <div class="sponsor-list swiper">
                        <div class="swiper-wrapper">
                            <?php foreach ($list as $item) : ?>
                                <div class="swiper-slide">
                                    <article class="sponsor-li">
                                        <div class="sponsor-li-image">
                                            <?php echo knot_image($item['image']); ?>
                                        </div>

                                        <div class="sponsor-li-content content">
                                            <?php echo KnotContent::renderContent(
                                                    $item['title'],
                                                    $item['text'],
                                                    null,
                                                    false,
                                                    '',
                                                    'title h4',
                                            ); ?>

                                            <?php echo do_shortcode($item['shortcode']); ?>
                                            <!--                                            <div class="progress" style="--progress: 80%">-->
                                            <!--                                                Raised $120 of $150-->
                                            <!--                                            </div>-->

                                            <?php the_crb_button($item); ?>
                                        </div>
                                    </article>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <?php
    });
};