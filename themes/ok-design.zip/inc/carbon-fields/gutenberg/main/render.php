<?php if (!defined('ABSPATH')) exit;

$block_name = 'main';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="main"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="main-net flex-center-between">
                    <div class="main-content">
                        <?php if ($rating_logo || $rating_count || $rating_stars) : ?>
                            <div class="rating flex-center-start">
                                <?php if ($rating_logo) : ?>
                                    <div class="rating-logo">
                                        <?php echo knot_image($rating_logo); ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ($rating_count) : ?>
                                    <div class="rating-count"><?php echo $rating_count; ?></div>
                                <?php endif; ?>

                                <?php if ($rating_stars) : ?>
                                    <div class="rating-stars">
                                        <?php echo knot_image($rating_stars); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <div class="content">
                            <?php if ($list) : ?>
                                <ul class="steps">
                                    <?php foreach ($list as $step) : ?>
                                        <li><?php echo $step['name']; ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>

                            <?php echo KnotContent::renderContent(
                                    $title,
                                    $text,
                                    null,
                                    false,
                                    '',
                                    'title h1',
                            ); ?>

                            <?php the_crb_button($fields); ?>
                        </div>
                    </div>
                    <?php if ($image) : ?>
                        <div class="main-image">
                            <?php echo knot_image($image); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
    });
};