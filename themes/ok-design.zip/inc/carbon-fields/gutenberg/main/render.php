<?php if (!defined('ABSPATH')) exit;

$block_name = 'main';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="main"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="main-background">
                    <?php echo knot_image($image); ?>
                </div>

                <div class="main-content content">
                    <?php echo KnotContent::renderContent(
                            $title,
                            $text,
                            null,
                            false,
                            '',
                            'title h1',
                    ); ?>

                    <div class="main-button flex-center-start">
                        <?php the_crb_button($fields); ?>
                        <?php the_crb_button([
                                'button_text' => $two_button_text ?? '',
                                'button_type' => $two_button_type ?? '',
                                'button_link' => $two_button_link ?? '',
                                'button_new_window' => $two_button_new_window ?? '',
                                'button_icon' => $two_button_icon ?? '',
                                'button_arrow' => $two_button_arrow ?? '',
                                'button_color' => $two_button_color ?? '',
                                'button_file' => $two_button_file ?? '',
                                'button_page' => $two_button_page ?? '',
                                'button_video' => $two_button_video ?? '',
                        ]); ?>
                    </div>
                </div>
            </div>
        </section>
        <?php
    });
};