<?php if (!defined('ABSPATH')) exit;

$block_name = 'banner';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="banner"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="banner-wrapper">
                    <div class="banner-content content">
                        <?php if ($title) : ?>
                            <div class="title h2">
                                <?php echo apply_filters('the_content', $title); ?>
                            </div>
                        <?php endif; ?>

                        <?php the_crb_button($fields); ?>
                    </div>
                    <?php if ($gallery) : ?>
                        <div class="banner-lines">
                            <?php
                                $line = '<div class="banner-line swiper">';
                                $line .= '<div class="swiper-wrapper">';
                                $index = 0;
                                foreach ($gallery as $image_id) {
                                    $index = $index > 2 ? 1 : $index + 1;
                                    $line .= '<div class="swiper-slide">';
                                    $line .= knot_image($image_id);
                                    $line .= '</div>'; // swiper-slide
                                    $line .= '<div class="swiper-slide">';
                                    $line .= knot_image_dir("svg/d{$index}");
                                    $line .= '</div>'; // swiper-slide
                                }
                                $line .= '</div>'; // swiper-wrapper
                                $line .= '</div>'; // swiper
                            ?>
                            <?php echo $line; ?>
                            <?php echo $line; ?>
                            <?php echo $line; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
    });
};