
<?php if (!defined('ABSPATH')) exit;

$block_name = 'gutenberg';

return function ($fields) use ($block_name) {
	crb_render_block($block_name, $fields, function ($fields) {
		extract($fields);
		$section_id = $section_id ?? '';
		$section_top = $section_top ?? '';
		?>
		<section class="gutenberg"
			<?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
			<?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
		>
            
		</section>
		<?php
	});
};