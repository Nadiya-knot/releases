<?php if (!defined('ABSPATH')) exit;

$block_name = 'solo';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="solo"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="solo-top content">
                    <?php if ($label) : ?>
                        <div class="label">
                            <?php echo apply_filters('the_content', $label); ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($title) : ?>
                        <div class="title h2">
                            <?php echo apply_filters('the_content', $title); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="solo-net grid-two">
                    <div class="solo-content">
                        <?php foreach ($list as $item) : ?>
                            <div class="content">
                                <?php if ($item['title']) : ?>
                                    <div class="title h6">
                                        <?php if ($item['icon']) echo knot_image($item['icon']); ?>
                                        <?php echo apply_filters('the_content', $item['title']); ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ($item['text']) : ?>
                                    <div class="richText">
                                        <?php echo apply_filters('the_content', $item['text']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>

                        <?php if ($counter) : ?>
                            <div class="content">
                                <?php if ($counter_title) : ?>
                                    <div class="title h6">
                                        <?php echo apply_filters('the_content', $counter_title); ?>
                                    </div>
                                <?php endif; ?>

                                <div class="grid-three">
                                    <?php foreach ($counter as $item) : ?>
                                        <div class="solo-item">
                                            <p class="title h2">
                                                <?php if ($item['before']) echo $item['before']; ?>
                                                <span data-number="<?php echo $item['count']; ?>">0</span>
                                                <?php if ($item['after']) echo $item['after']; ?>
                                            </p>

                                            <?php if ($item['text']) echo "<p>{$item['text']}</p>"; ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($image) : ?>
                        <div class="solo-image">
                            <?php echo knot_image($image); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
    });
};