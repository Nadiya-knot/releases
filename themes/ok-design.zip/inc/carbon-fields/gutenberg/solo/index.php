<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

$block_name = 'solo';

crb_register_block_assets($block_name);

crb_create_block(
    $block_name,
    function () use ($block_name) {
        return array_merge(
            array_filter([crb_preview_field($block_name)]),
            [Field::make('rich_text', 'label', __('Label'))],
            [Field::make('rich_text', 'title', __('Title'))],
            [Field::make('image', 'image', __('Image'))->set_type(array('image'))],
        );
    },
    require __DIR__ . '/render.php',
    function () {
        return [
            __('Content') => [
                Field::make('complex', 'list', '')->set_collapsed(true)
                    ->add_fields([
                        Field::make('image', 'icon', __('Icon'))->set_type(array('image')),
                        Field::make('rich_text', 'title', __('Title')),
                        Field::make('rich_text', 'text', __('Text')),
                    ])
                    ->set_header_template('
						<% if (title) { %>
							<%- _.unescape(title).replace(/<[^>]*>/g, "") %>
						<% } %>
					'),
            ],
            __('Counts') => [
                Field::make('rich_text', 'counter_title', __('Title')),

                Field::make('complex', 'counter', '')->set_collapsed(true)
                    ->add_fields([
                        Field::make('text', 'before', __('Before'))->set_width(30),
                        Field::make('text', 'count', __('Number'))
                            ->set_attribute('type', 'number')
                            ->set_attribute('step', '1')
                            ->set_width(40),
                        Field::make('text', 'after', __('After'))->set_width(30),
                        Field::make('text', 'text', __('Text')),
                    ])
                    ->set_header_template('
						<% if (text) { %>
							<%- _.unescape(text).replace(/<[^>]*>/g, "") %>
						<% } %>
					'),
            ]
        ];
    }
);