<?php if (!defined('ABSPATH')) exit;

$block_name = 'country';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="country"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="country-head flex-end-between">
                    <?php echo KnotContent::renderContent(
                            $title,
                            $text,
                            null,
                            true,
                            '',
                            'title h3',
                    ); ?>

                    <?php the_crb_button($fields); ?>
                </div>
                <?php $country = knot_crb_theme('country-list'); ?>

                <?php if ($country) : ?>
                    <div class="country-list grid-three" id="countryList">
                        <?php foreach ($country as $item) : ?>
                            <button class="country-li" data-id="<?php echo $item['id']; ?>">
                            <span class="country-li-icon">
                                <?php echo knot_image($item['icon']); ?>
                            </span>
                                <span class="country-li-name title h6"><?php echo esc_html($item['name']); ?></span>
                                <i class="icon-arrow-next"></i>
                            </button>
                        <?php endforeach; ?>
                    </div>

                    <div class="country-content" id="countryContent" style="display: none"></div>

                    <?php
                    $country_data = [];
                    foreach ($country as $item) {
                        $country_data[$item['id']] = [
                                'name' => $item['name'],
                                'title' => $item['title'],
                                'text' => $item['text'],
                                'image' => wp_get_attachment_image_url($item['map'], 'full'),
                        ];
                    }

                    wp_localize_script("knot-main", 'countryData', $country_data);

                    add_action('wp_footer', function () {
                        get_template_part( 'templates/modal', 'country');
                    });
                    ?>
                <?php endif; ?>
            </div>
        </section>
        <?php
    });
};