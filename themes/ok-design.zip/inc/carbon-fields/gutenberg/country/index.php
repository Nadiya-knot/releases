<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

$block_name = 'country';

crb_register_block_assets($block_name);

crb_create_block(
    $block_name,
    function () use ($block_name) {
        return array_merge(
            array_filter([crb_preview_field($block_name)]),
            [Field::make('rich_text', 'title', __('Title'))],
            [Field::make('rich_text', 'text', __('Text'))],
        );
    },
    require __DIR__ . '/render.php',
    function () {
        return [
            __('Button') => crb_button_fields(),
        ];
    }
);