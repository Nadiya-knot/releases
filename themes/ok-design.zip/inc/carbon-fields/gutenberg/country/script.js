document.addEventListener("DOMContentLoaded", () => {
    const countryList = document.getElementById("countryList");
    const content = document.getElementById("countryContent");
    const buttons = countryList.querySelectorAll("button");
    const hiddenInput = document.querySelector('input[name="select-country"]');

    content.style.display = "none";

    buttons.forEach((btn) => {
        btn.addEventListener("click", () => {
            const id = btn.dataset.id;
            const c = countryData[id];

            content.innerHTML = `
                <div class="country-content-net flex-start-between">
                    <div class="country-content-info">
                        <div class="country-content-breadcrumbs">
                            <button id="backToList">Choose your country</button>
                            <i class="icon-arrow-next"></i>
                            <span>${c.name}</span>
                        </div>
                        <div class="content">
                            <div class="title h2"><p>${c.title}</p></div>
                            <div class="richText"><p>${c.text}</p></div>
                            <button class="button button-white button-icon" 
                                    data-action="open" 
                                    data-modal="modal-country"
                                    data-country-id="${id}">
                                Start Your Request <i class="icon-arrow"></i>
                            </button>
                        </div>
                    </div>
                    <div class="country-content-image">
                        <img src="${c.image}" alt="${c.name}">
                    </div>
                </div>
            `;

            countryList.style.display = "none";
            content.style.display = "block";

            // Кнопка "назад"
            content.querySelector("#backToList").addEventListener("click", () => {
                content.style.display = "none";
                countryList.style.display = "grid";
            });
        });
    });

    // Підстановка id країни
    document.addEventListener("click", (e) => {
        const btn = e.target.closest('[data-action="open"][data-modal="modal-country"]');
        if (!btn) return;

        const countryId = btn.dataset.countryId;
        if (hiddenInput) hiddenInput.value = countryId;
    });
});