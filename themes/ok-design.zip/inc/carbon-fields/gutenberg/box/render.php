<?php if (!defined('ABSPATH')) exit;

$block_name = 'box';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="box"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="box-wrapper">
                    <?php if ($text) : ?>
                        <div class="richText fs-h5">
                            <?php echo apply_filters('the_content', $text); ?>
                        </div>
                    <?php endif; ?>

                    <div class="box-bottom flex-end-between">
                        <?php crb_render_user($fields); ?>

                        <?php the_crb_button($fields); ?>
                    </div>
                </div>
            </div>
        </section>
        <?php
    });
};