<?php if (!defined('ABSPATH')) exit;

$block_name = 'word';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="word"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="word-wrapper">
                    <?php echo KnotContent::renderContent(
                            $title,
                            $text,
                            null,
                            true,
                            'word-head',
                            'title h3',
                    ); ?>

                    <div class="word-content content">
                        <?php if ($list) : ?>
                            <div class="word-list content">
                                <?php foreach ($list as $item) : ?>
                                    <?php if (!$item['name'] && !$item['text']) continue; ?>
                                    <div class="word-li">
                                        <div class="word-li__trigger">
                                            <?php if ($item['icon']) : ?>
                                                <div class="word-li__icon">
                                                    <?php echo knot_image($item['icon']); ?>
                                                </div>
                                            <?php endif; ?>

                                            <div class="title h5">
                                                <?php echo apply_filters('the_content', $item['name']); ?>
                                            </div>
                                        </div>
                                        <div class="word-li__content">
                                            <div class="richText">
                                                <?php echo apply_filters('the_content', $item['text']); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <?php the_crb_button($fields); ?>
                    </div>

                    <?php if ($image) : ?>
                        <div class="word-image">
                            <?php echo knot_image($image); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
    });
};