<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

/**
 * Отримує шляхи/URL до CSS, JS та прев’ю файлів блока
 *
 * @param string $block_name Назва папки блока
 * @return array Массив з ключами: style, script, preview
 */
function crb_get_block_assets(string $block_name): array
{
    $base_path = "inc/carbon-fields/gutenberg/{$block_name}/";

    $assets = [
        'style' => null,
        'script' => null,
        'preview' => null,
    ];

    if (file_exists(get_theme_file_path($base_path . 'style.css'))) {
        $assets['style'] = [
            'handle' => "gutenberg-{$block_name}-style",
            'url' => get_theme_file_uri($base_path . 'style.css'),
        ];
    }

    if (file_exists(get_theme_file_path($base_path . 'script.js'))) {
        $assets['script'] = [
            'handle' => "gutenberg-{$block_name}-script",
            'url' => get_theme_file_uri($base_path . 'script.js'),
        ];
    }

    if (file_exists(get_theme_file_path($base_path . 'preview.jpg'))) {
        $assets['preview'] = get_theme_file_uri($base_path . 'preview.jpg');
    }

    return $assets;
}

/**
 * Реєструє CSS/JS файли блока для Gutenberg
 *
 * @param string $block_name Назва блока
 */
function crb_register_block_assets(string $block_name): void
{
    $assets = crb_get_block_assets($block_name);

    if ($assets['style']) {
        wp_register_style($assets['style']['handle'], $assets['style']['url'], [], THEME_VERSION);
    }

    if ($assets['script']) {
        wp_register_script($assets['script']['handle'], $assets['script']['url'], ['jquery'], THEME_VERSION, true);
    }

    wp_register_style('knot-main-admin', THEME_URI . '/front/styles/main-admin.min.css', array(), THEME_VERSION);
}

/**
 * Повертає HTML поле для прев’ю блока (якщо існує preview.jpg)
 *
 * @param string $block_name Назва блока
 * @param string $label Мітка поля
 * @return ?Carbon_Fields\Field Поле Carbon Fields або null
 */
function crb_preview_field(string $block_name, string $label = 'Section Description')
{
    $preview_path = "inc/carbon-fields/gutenberg/{$block_name}/screenshot.jpg";

    if (file_exists(get_theme_file_path($preview_path))) {
        $preview_url = get_theme_file_uri($preview_path);
        return Field::make('html', 'crb_html', __($label))
            ->set_html("<img src='{$preview_url}' alt='Preview'>");
    }

    return null;
}