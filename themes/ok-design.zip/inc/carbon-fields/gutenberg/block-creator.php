<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Block;
use Carbon_Fields\Field;

/**
 * Створює блок для Gutenberg з Carbon Fields
 *
 * @param string   $block_name Назва блока (і папки)
 * @param callable $fields_callback Функція, що повертає масив полів
 * @param callable $render_callback Функція рендера блока
 * @param callable|null $tabs_callback Функція, що повертає масив вкладок (опціонально)
 * @return Carbon_Fields\Block
 */
function crb_create_block(
    string $block_name,
    callable $fields_callback,
    callable $render_callback,
    ?callable $tabs_callback = null
) {
    $assets = crb_get_block_assets($block_name);

    $block = Block::make($block_name . ' section')
        ->add_fields($fields_callback())
        ->set_mode('preview')
        ->set_icon('feedback')
        ->set_category('custom-category', 'Theme block', 'sections')
        ->set_inner_blocks(false)
        ->set_inner_blocks_position('below')
        ->set_render_callback($render_callback);

    if (is_admin()) {
        $block->set_style('knot-main-admin');
    }

    // Додаємо стилі редактора, якщо вони є
    if ($assets['style']) {
        $block->set_editor_style($assets['style']['handle']);
    }

    // Підключаємо скрипти для адміністратора
    if (is_admin() && $assets['script']) {
        wp_enqueue_script($assets['script']['handle']);
    }

    // Додаємо вкладки, якщо передано callback
    if ($tabs_callback) {
        $tabs = $tabs_callback();
        foreach ($tabs as $tab_name => $tab_fields) {
            $block->add_tab($tab_name, $tab_fields);
        }

    }

	// Завжди додаємо вкладку Setting
	$block->add_tab(__('Setting'), [
		Field::make('text', 'section_id', __('Unique section identifier')),
		Field::make('text', 'section_top', __('Scroll stop position'))->set_attribute('type', 'number'),
	]);

    return $block;
}

/**
 * Рендерить блок на фронтенді
 *
 * @param string   $block_name Назва блока
 * @param array    $fields Поля блока
 * @param callable $template_callback Функція рендера шаблону
 */
function crb_render_block(string $block_name, array $fields, callable $template_callback): void {
    $assets = crb_get_block_assets($block_name);

    if ($assets['style']) {
        wp_enqueue_style($assets['style']['handle']);
    }

    if ($assets['script'] && !is_admin()) {
        wp_enqueue_script($assets['script']['handle']);
    }

    // Якщо є значення полів — рендеримо шаблон, інакше показуємо прев’ю
    if (!empty(array_filter($fields))) {
        call_user_func($template_callback, $fields);
    } elseif ($assets['preview']) {
        echo "<img src='{$assets['preview']}' alt='Preview'>";
    }
}