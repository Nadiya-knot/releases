<?php if (!defined('ABSPATH')) exit;

$block_name = 'reviews';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="reviews"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="container">
                <div class="reviews-top content content-center">
                    <?php if ($label) : ?>
                        <div class="label">
                            <?php echo apply_filters('the_content', $label); ?>
                        </div>
                    <?php endif; ?>

                    <?php echo KnotContent::renderContent($title, $text, null, false, '', 'title h2'); ?>
                </div>

                <?php if ($list) : ?>
                    <div class="reviews-list-wrapper">
                        <div class="reviews-list swiper">
                            <div class="swiper-wrapper">
                                <?php foreach ($list as $item) : ?>
                                    <div class="swiper-slide">
                                        <div class="review-item">
                                            <div class="content">
                                                <?php if ($item['review_logo'] || $item['review_stars']) : ?>
                                                    <div class="review-item-head">
                                                        <?php if ($item['review_logo']) : ?>
                                                            <div class="review-item-logo">
                                                                <?php echo knot_image($item['review_logo']); ?>
                                                            </div>
                                                        <?php endif; ?>

                                                        <?php if (!empty($item['review_stars'])) : ?>
                                                            <div class="review-item-stars">
                                                                <?php
                                                                $stars = (int)$item['review_stars'];
                                                                for ($i = 1; $i <= 5; $i++) {
                                                                    echo '<span' . ($i <= $stars ? ' class="active"' : '') . '></span>';
                                                                }
                                                                ?>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>

                                                <?php echo KnotContent::renderContent($item['title'], $item['text'], null, false, '', 'title h6'); ?>

                                                <?php if ($item['video']) {
                                                    $posterUrl = isset($item['poster']) ? wp_get_attachment_image_url($item['poster'], 'full') : '';
                                                    $attributes = 'preload="metadata"';
                                                    if ($posterUrl) {
                                                        $attributes .= ' poster="' . $posterUrl . '"';
                                                    }

                                                    echo knot_video($item['video'], '', $attributes);
                                                } ?>
                                            </div>

                                            <?php crb_render_user($item); ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="swiper-pagination"></div>
                        </div>
                        <div class="swiper-button">
                            <button class="swiper-button-prev"></button>
                            <button class="swiper-button-next"></button>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <?php
    });
};