<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

$block_name = 'reviews';

crb_register_block_assets($block_name);

crb_create_block(
    $block_name,
    function () use ($block_name) {
        return array_merge(
            array_filter([crb_preview_field($block_name)]),
            [Field::make('rich_text', 'label', __('Label'))],
            [Field::make('rich_text', 'title', __('Title'))],
            [Field::make('rich_text', 'text', __('Text'))],
        );
    },
    require __DIR__ . '/render.php',
    function () {
        return [
            __('Reviews') => [
                Field::make('complex', 'list', '')->set_collapsed(true)
                    ->add_fields([
                        Field::make('image', 'review_logo', __('Logo'))->set_type(array('image')),
                        Field::make('radio', 'review_stars', __('Stars'))->add_options([
                            '1' => '1',
                            '2' => '2',
                            '3' => '3',
                            '4' => '4',
                            '5' => '5',
                        ]),
                        Field::make('rich_text', 'title', __('Title')),
                        Field::make('rich_text', 'text', __('Text')),
                        Field::make('image', 'video', __('Video'))->set_type(array('video')),

                        ...crb_user_fields('', true),
                    ])
                    ->set_header_template('
						<% if (title) { %>
							<%- _.unescape(title).replace(/<[^>]*>/g, "") %>
						<% } %>
					'),
            ]
        ];
    }
);