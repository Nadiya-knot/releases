<?php if (!defined('ABSPATH')) exit;

$block_name = 'partners';

return function ($fields) use ($block_name) {
    crb_render_block($block_name, $fields, function ($fields) {
        extract($fields);
        $section_id = $section_id ?? '';
        $section_top = $section_top ?? '';
        ?>
        <section class="partners"
                <?php echo $section_id ? "id=\"{$section_id}\"" : ''; ?>
                <?php echo $section_top ? "data-top=\"{$section_top}\"" : ''; ?>
        >
            <div class="partners-decoration decoration">
                <?php echo knot_image_dir('svg/dec/partners'); ?>
            </div>
            <div class="container">
                <?php if ($title) : ?>
                    <div class="partners-title title h4">
                        <?php echo apply_filters('the_content', $title); ?>
                    </div>
                <?php endif; ?>

                <?php if ($gallery) : ?>
                    <div class="partners-swiper swiper">
                        <div class="swiper-gradient"></div>
                        <div class="swiper-wrapper">
                            <?php foreach ($gallery as $image_id) : ?>
                                <div class="swiper-slide"><?php echo knot_image($image_id); ?></div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <?php
    });
};