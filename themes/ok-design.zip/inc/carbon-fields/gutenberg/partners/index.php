<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Field;

$block_name = 'partners';

crb_register_block_assets($block_name);

crb_create_block(
    $block_name,
    function () use ($block_name) {
        return array_merge(
            array_filter([crb_preview_field($block_name)]),
            [Field::make('rich_text', 'title', __('Title'))],
            [Field::make('media_gallery', 'gallery', __('Gallery'))],
        );
    },
    require __DIR__ . '/render.php',
);