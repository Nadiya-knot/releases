<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Container;
use Carbon_Fields\Field;


// Social menu
Container::make('nav_menu_item', __('Menu Settings'))
	->add_fields([
		Field::make('image', 'image', __('Image'))
			->set_type(array('image'))
	]);

add_filter('walker_nav_menu_start_el', function ($item_output, $item, $depth, $args) {
	$location = $args->theme_location;
	$image_id = carbon_get_nav_menu_item_meta($item->ID, 'image');

	if ($location === 'social' && $image_id) {
		$image = wp_get_attachment_image_url($image_id);
		$target = $item->target ? ' target="' . esc_attr($item->target) . '"' : '';
		$rel = $item->xfn ? ' rel="' . esc_attr($item->xfn) . '"' : '';

		$item_output = <<<HTML
			<a href="{$item->url}"{$target}{$rel}>
			    <i style="mask-image: url('{$image}')"></i>
			</a>
		HTML;
	}

	return $item_output;
}, 10, 4);