<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Container;
use Carbon_Fields\Field;


// Social menu
Container::make('nav_menu_item', __('Menu Settings'))
	->add_fields([
		Field::make('image', 'image', __('Image'))
			->set_type(array('image')),
        Field::make('checkbox', 'download', __('Download')),
        Field::make('checkbox', 'soon', __('Soon')),
	]);

add_filter('walker_nav_menu_start_el', function ($item_output, $item, $depth, $args) {
	$image_id = carbon_get_nav_menu_item_meta($item->ID, 'image');
	$download = carbon_get_nav_menu_item_meta($item->ID, 'download');
	$soon = carbon_get_nav_menu_item_meta($item->ID, 'soon');

	$download_attr = $download ? ' download' : '';

	if ($soon) {
		$text = strip_tags($item_output);
		$item_output = '<span class="menu-soon">' . esc_html($text) . ' <span class="soon-text">Soon</span></span>';
	} else {
		$item_output = preg_replace(
			'/<a\s+/i',
			'<a' . $download_attr . ' ',
			$item_output,
			1
		);
	}

	if ($args->theme_location === 'social' && $image_id) {
		$image = wp_get_attachment_image_url($image_id);
		$target = $item->target ? ' target="' . esc_attr($item->target) . '"' : '';
		$rel = $item->xfn ? ' rel="' . esc_attr($item->xfn) . '"' : '';

		$item_output = <<<HTML
			<a href="{$item->url}"{$target}{$rel}{$download_attr}>
			    <i style="mask-image: url('{$image}')"></i>
			</a>
		HTML;
	}

	return $item_output;
}, 10, 4);