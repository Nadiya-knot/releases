<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

if (function_exists('pll_current_language') && knot_lang_prefix() === '_all') {
    $basic_options_container = Container::make('theme_options', __('Theme Options'))
        ->set_icon('dashicons-welcome-widgets-menus')
        ->add_fields(array(
            Field::make('html', 'all_lang')
                ->set_html('<h2>To customize the fields, select the language in the top navigation</h2>')
        ));

    return;
}

// Default options page
$basic_options_container = Container::make('theme_options', __('Theme Options'))
    ->set_icon('dashicons-welcome-widgets-menus')
    ->add_tab(__('Scripts'), array(
        Field::make('header_scripts', 'crb_header_scripts', __('Head'))->set_width(50),
//        Field::make('header_scripts', 'crb_header_scripts' . knot_lang_prefix(), __('Head (Language)'))->set_width(50),
        Field::make('footer_scripts', 'crb_footer_scripts', __('Body'))->set_width(50),
//        Field::make('footer_scripts', 'crb_footer_scripts' . knot_lang_prefix(), __('Body (Language)'))->set_width(50),
    ))
    ->add_tab(__('404'), array(
        Field::make('rich_text', 'error-404-title' . knot_lang_prefix(), __('Title'))->set_width(50),
        Field::make('rich_text', 'error-404-text' . knot_lang_prefix(), __('Text'))->set_width(50),
        Field::make('image', 'error-404-image' . knot_lang_prefix(), __('Image'))->set_type(array('image'))->set_width(33),
    ))
    ->add_tab(__('Header'), array(
        ...crb_button_fields('header' . knot_lang_prefix()),
    ))
    ->add_tab(__('Footer'), array(
        Field::make('rich_text', 'footer-title' . knot_lang_prefix(), __('Title'))->set_width(50),
        Field::make('rich_text', 'footer-text' . knot_lang_prefix(), __('Text'))->set_width(50),
        Field::make('text', 'footer-shortcode', __('Shortcode'))->set_width(50),

        Field::make('text', 'footer-copyright' . knot_lang_prefix(), __('Copyright')),
    ))
    ->add_tab(__('Modal - donate'), array(
        Field::make('rich_text', 'modal-donate-title' . knot_lang_prefix(), __('Title'))->set_width(50),
        Field::make('rich_text', 'modal-donate-text' . knot_lang_prefix(), __('Text'))->set_width(50),
        Field::make('textarea', 'modal-donate-ember', __('Ember code'))->set_width(50),
    ))
    ->add_tab(__('Modal - country'), array(
        Field::make('text', 'modal-country-shortcode', __('Shortcode'))->set_width(50),
    ))
    ->add_tab(__('Modal - thank'), array(
        Field::make('rich_text', 'modal-thank-title' . knot_lang_prefix(), __('Title'))->set_width(50),
        Field::make('rich_text', 'modal-thank-text' . knot_lang_prefix(), __('Text'))->set_width(50),
        ...crb_button_fields('thank' . knot_lang_prefix(), true),
        ...crb_button_fields('thank_two' . knot_lang_prefix(), true),
    ));


/*-----------------------------------------------------------------------------------*/
/* Country */
/*-----------------------------------------------------------------------------------*/

Container::make( 'theme_options', __( 'Country' ) )
    ->set_page_parent( $basic_options_container )
    ->add_fields( array(
        Field::make('complex', 'country-list', '')->set_collapsed(true)
            ->add_fields([
                Field::make('image', 'icon', __('Icon'))->set_type(array('image'))->set_width(50),
                Field::make('image', 'map', __('Map'))->set_type(array('image'))->set_width(50),
                Field::make('text', 'name', __('Name'))->set_width(50),
                Field::make('text', 'id', __('Id'))->set_width(50),
                Field::make('rich_text', 'title', __('Title'))->set_width(50),
                Field::make('rich_text', 'text', __('Text'))->set_width(50),
            ])
            ->set_header_template('
                <% if (name) { %>
                    <%- _.unescape(name).replace(/<[^>]*>/g, "") %>
                <% } %>
            ')
    ) );