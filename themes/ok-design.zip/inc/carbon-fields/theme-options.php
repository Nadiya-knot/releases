<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

if (function_exists('pll_current_language') && knot_lang_prefix() === '_all') {
    $basic_options_container = Container::make('theme_options', __('Theme Options'))
        ->set_icon('dashicons-welcome-widgets-menus')
        ->add_fields(array(
            Field::make('html', 'all_lang')
                ->set_html('<h2>To customize the fields, select the language in the top navigation</h2>')
        ));

    return;
}

// Default options page
$basic_options_container = Container::make('theme_options', __('Theme Options'))
    ->set_icon('dashicons-welcome-widgets-menus')
    ->add_tab(__('Scripts'), array(
        Field::make('header_scripts', 'crb_header_scripts', __('Head'))->set_width(50),
//        Field::make('header_scripts', 'crb_header_scripts' . knot_lang_prefix(), __('Head (Language)'))->set_width(50),
        Field::make('footer_scripts', 'crb_footer_scripts', __('Body'))->set_width(50),
//        Field::make('footer_scripts', 'crb_footer_scripts' . knot_lang_prefix(), __('Body (Language)'))->set_width(50),
    ))
    ->add_tab(__('404'), array(
        Field::make('rich_text', 'error-404-title' . knot_lang_prefix(), __('Title'))->set_width(50),
        Field::make('rich_text', 'error-404-text' . knot_lang_prefix(), __('Text'))->set_width(50),
        Field::make('image', 'error-404-image' . knot_lang_prefix(), __('Image'))->set_type(array('image'))->set_width(33),
    ))
    ->add_tab(__('Header'), array(
        ...crb_button_fields('header' . knot_lang_prefix()),
    ))
    ->add_tab(__('Footer'), array(
        Field::make('rich_text', 'footer-label' . knot_lang_prefix(), __('Label'))->set_width(50),
        Field::make('rich_text', 'footer-title' . knot_lang_prefix(), __('Title'))->set_width(50),
        Field::make('rich_text', 'footer-text' . knot_lang_prefix(), __('Text'))->set_width(50),
        Field::make('text', 'footer-copyright' . knot_lang_prefix(), __('Copyright'))->set_width(50),

        ...crb_button_fields('footer' . knot_lang_prefix()),
    ));