<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

// Thank
Container::make('post_meta', __('Інформація сторінки'))
    ->where('post_template', '=', 'thank.php')
    ->add_fields(array(
        Field::make('image', 'background', __('Background'))->set_type(array('image'))->set_width(20),
        Field::make('image', 'image_1', __('Image 1'))->set_type(array('image'))->set_width(20),
        Field::make('image', 'image_2', __('Image 2'))->set_type(array('image'))->set_width(20),
        Field::make('rich_text', 'title', __('Title'))->set_width(40),
    ));