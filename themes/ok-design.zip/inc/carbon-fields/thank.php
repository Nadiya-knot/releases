<?php if (!defined('ABSPATH')) exit;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

// Thank
Container::make('post_meta', __('Page info'))
    ->where('post_template', '=', 'thank.php')
    ->add_fields(array(
        Field::make('rich_text', 'title', __('Title'))->set_width(50),
        Field::make('rich_text', 'text', __('Text'))->set_width(50),
    ));