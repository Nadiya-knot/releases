<?php if (!defined('ABSPATH')) exit;

// Вивід чекбокса у меню
add_action('wp_nav_menu_item_custom_fields', function($item_id, $item){
    $value = get_post_meta($item_id, '_menu_item_download', true);
    ?>
    <p class="field-download description description-wide">
        <label for="edit-menu-item-download-<?php echo $item_id; ?>">
            <input type="checkbox"
                   id="edit-menu-item-download-<?php echo $item_id; ?>"
                   name="menu-item-download[<?php echo $item_id; ?>]"
                   <?php checked($value, '1'); ?> />
            Download
        </label>
    </p>
    <?php
}, 10, 2);

// Збереження
add_action('wp_update_nav_menu_item', function($menu_id, $menu_item_db_id){
    if (isset($_POST['menu-item-download'][$menu_item_db_id])) {
        update_post_meta($menu_item_db_id, '_menu_item_download', '1');
    } else {
        delete_post_meta($menu_item_db_id, '_menu_item_download');
    }
}, 10, 2);

// Додавання в <a>
add_filter('nav_menu_link_attributes', function($atts, $item){
    if (!empty(get_post_meta($item->ID, '_menu_item_download', true))) {
        $atts['download'] = '';
    }
    return $atts;
}, 10, 2);