<?php if (!defined('ABSPATH')) exit;

// Підключаємо TGM Plugin Activation
require_once get_template_directory() . '/inc/class-tgm-plugin-activation.php';

function my_theme_register_required_plugins() {
    $plugins = array(
        array(
            'name'      => 'SVG Support',
            'slug'      => 'svg-support',
            'required'  => false,
        ),
        array(
            'name'      => 'TinyPNG',
            'slug'      => 'tiny-compress-images',
            'required'  => false,
        ),
        array(
            'name'      => 'Carbon Fields',
            'slug'      => 'carbon-fields',
            'source'    => THEME_DIR . '/inc/carbon-fields/carbon-fields.zip',
            'required'  => true,
        ),
    );

    $config = array(
        'id'           => 'knot',
        'menu'         => 'install-theme-plugins',
        'has_notices'  => true,
        'dismissable'  => false,
        'is_automatic' => true,
    );

    tgmpa( $plugins, $config );
}
add_action( 'tgmpa_register', 'my_theme_register_required_plugins' );
