<?php

if (!defined('ABSPATH')) exit;

function register_cases_cpt()
{
    $args = array(
        'label' => 'Cases',
        'public' => true,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-portfolio',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'revisions'),
        'has_archive' => true,
        'rewrite' => array('slug' => 'cases'),
        'taxonomies' => array('case_category'),
        'show_in_rest' => true,
    );

    register_post_type('cases', $args);
}

add_action('init', 'register_cases_cpt');

function register_cases_categories()
{
    $args = array(
        'labels' => array(
            'name' => 'Case Categories',
            'singular_name' => 'Case Category',
            'all_items' => 'All Case Categories',
            'edit_item' => 'Edit Category',
            'update_item' => 'Update Category',
            'add_new_item' => 'Add New Category',
            'new_item_name' => 'New Category Name',
            'menu_name' => 'Case Categories',
        ),
        'hierarchical' => false,
        'show_admin_column' => true,
        'rewrite' => array('slug' => 'case-category'),
        'show_in_rest' => true,
    );

    register_taxonomy('case_category', array('cases'), $args);
}

add_action('init', 'register_cases_categories');