<?php if (!defined('ABSPATH')) exit;

if (!defined('ABSPATH')) {
	exit;
}

function knot_setup()
{
	add_theme_support('automatic-feed-links');

	add_theme_support('title-tag');

	add_theme_support('post-thumbnails');

	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	add_theme_support('customize-selective-refresh-widgets');

	add_theme_support(
		'custom-logo',
		array(
			'height' => 250,
			'width' => 250,
			'flex-width' => true,
			'flex-height' => true,
		)
	);
}

add_action('after_setup_theme', 'knot_setup');


function knot_content_width()
{
	$GLOBALS['content_width'] = apply_filters('knot_content_width', 640);
}

add_action('after_setup_theme', 'knot_content_width', 0);


/*-----------------------------------------------------------------------------------*/
/* Navigation */
/*-----------------------------------------------------------------------------------*/

register_nav_menus($locations = array(
	'navigation' => 'Navigation',
	'social' => 'Social media',
    'projects' => 'Projects',
    'policy' => 'Policy',
));