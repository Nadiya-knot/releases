<?php
/*
Template Name: Thank
*/

get_header(); ?>

    <main>
        <section class="thank">
            <div class="container">
                <div class="thank-content content">
                    <?php
                    echo KnotContent::renderContent(
                            carbon_get_the_post_meta('title'),
                            carbon_get_the_post_meta('text'),
                            [
                                    'button_type' => 'link',
                                    'button_text' => 'Back to Home',
                                    'button_link' => home_url(),
                            ],
                            false,
                            '',
                            'title h1',
                    );
                    ?>
                </div>
            </div>
        </section>
    </main>

    <style>
        body {
            display: flex;
            flex-direction: column;
        }

        main {
            display: flex;
            align-items: center;
            justify-content: center;

            flex: 1;
            min-height: 80dvh;
        }

        .thank {
            margin: 0 !important;
        }

        .thank-content {
            align-items: center;

            max-width: 680px;
            margin-block: var(--i1);
            text-align: center;
            text-wrap: balance;
        }
    </style>

<?php
get_footer();