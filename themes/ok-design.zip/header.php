<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php $navigation = function () {
    wp_nav_menu([
            'theme_location' => 'navigation',
            'container' => 'nav',
            'container_class' => '',
            'items_wrap' => '<ul>%3$s</ul>',
    ]);
} ?>

<header class="header">
    <div class="container">
        <div class="header-net flex-center-between">
            <div class="header-left flex-center-between">
                <?php the_custom_logo(); ?>
            </div>
            <div class="header-center flex-center-between">
                <?php if (knot_menu_exists('navigation')) : ?>
                    <?php $navigation(); ?>
                <?php endif; ?>
            </div>
            <div class="header-right flex-center-between">
                <?php the_crb_button('header' . knot_lang_prefix()); ?>
            </div>
        </div>
    </div>
</header>