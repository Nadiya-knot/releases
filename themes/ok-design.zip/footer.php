<footer class="footer">
    <div class="container">
        <div class="footer-head content content-center">
            <div class="label">
                <p>What’s Really Holding Back Your Business?</p>
            </div>
            <div class="title h2">
                <h2>We’re ready to build what moves you forward</h2>
            </div>
            <div class="richText">
                <p>Get everything you need in one place — design, development, and branding that actually help your
                    business grow.</p>
            </div>
            <div class="button">Book A Call</div>
        </div>
        <div class="footer-net flex-center-between">
            <div class="footer-left flex-start-between">
                <div class="footer-nav">
                    <p>About</p>
                    <nav>
                        <ul>
                            <li><a href="#about">About Us</a></li>
                            <li><a href="#faq">FAQ</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="footer-nav">
                    <p>Work</p>
                    <nav>
                        <ul>
                            <li><a href="#">Our Services</a></li>
                            <li><a href="#">Case Studies</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="footer-nav">
                    <p>Info</p>
                    <nav>
                        <ul>
                            <li><a href="#">Process</a></li>
                            <li><a href="#">Contact Us</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
            <div class="footer-right flex-start-between">
                <div class="footer-nav">
                    <p>Info</p>
                    <ul class="contact">
                        <li><a href="mailto:hello@okdesign.co.uk">hello@okdesign.co.uk</a></li>
                    </ul>
                    <nav class="socials">
                        <ul>
                            <li>
                                <a href="#">
                                    <i style="mask-image: url('front/images/inst.svg')"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i style="mask-image: url('front/images/br.svg')"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i style="mask-image: url('front/images/be.svg')"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i style="mask-image: url('front/images/in.svg')"></i>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <div class="footer-bottom flex-center-between">
            <p class="footer-copyright">© 2025 OK Design - Web Design Agency</p>
            <button class="footer-up" onclick="scrollToElement('html', {easing: sharpStartSlowEnd})"></button>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>

</body>
</html>
