<?php
$label = knot_crb_theme('footer-label');
$title = knot_crb_theme('footer-title');
$text = knot_crb_theme('footer-text');

$copyright = knot_crb_theme('footer-copyright');
?>

<footer class="footer">
    <div class="container">
        <div class="footer-head content content-center">
            <?php if ($label) : ?>
                <div class="label">
                    <?php echo apply_filters('the_content', $label); ?>
                </div>
            <?php endif; ?>

            <?php echo KnotContent::renderContent(
                    $title,
                    $text,
                    null,
                    false,
                    '',
                    'title h2',
            ); ?>

            <?php the_crb_button('footer' . knot_lang_prefix()); ?>
        </div>
        <?php if (knot_menu_exists('footer-col-1') || knot_menu_exists('footer-col-2') || knot_menu_exists('footer-col-3') || knot_menu_exists('footer-col-4') || knot_menu_exists('contact') || knot_menu_exists('social')) : ?>
            <div class="footer-net flex-start-between">
                <div class="footer-left flex-start-between">
                    <?php if (knot_menu_exists('footer-col-1')) : ?>
                        <div class="footer-nav">
                            <p><?php echo knot_menu_name('footer-col-1'); ?></p>
                            <?php wp_nav_menu([
                                    'theme_location' => 'footer-col-1',
                                    'container' => 'nav',
                                    'container_class' => '',
                                    'items_wrap' => '<ul>%3$s</ul>',
                            ]); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (knot_menu_exists('footer-col-2')) : ?>
                        <div class="footer-nav">
                            <p><?php echo knot_menu_name('footer-col-2'); ?></p>
                            <?php wp_nav_menu([
                                    'theme_location' => 'footer-col-2',
                                    'container' => 'nav',
                                    'container_class' => '',
                                    'items_wrap' => '<ul>%3$s</ul>',
                            ]); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (knot_menu_exists('footer-col-3')) : ?>
                        <div class="footer-nav">
                            <p><?php echo knot_menu_name('footer-col-3'); ?></p>
                            <?php wp_nav_menu([
                                    'theme_location' => 'footer-col-3',
                                    'container' => 'nav',
                                    'container_class' => '',
                                    'items_wrap' => '<ul>%3$s</ul>',
                            ]); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (knot_menu_exists('footer-col-4')) : ?>
                        <div class="footer-nav">
                            <p><?php echo knot_menu_name('footer-col-4'); ?></p>
                            <?php wp_nav_menu([
                                    'theme_location' => 'footer-col-4',
                                    'container' => 'nav',
                                    'container_class' => '',
                                    'items_wrap' => '<ul>%3$s</ul>',
                            ]); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="footer-right flex-start-between">
                    <?php if (knot_menu_exists('contact') || knot_menu_exists('social')) : ?>
                        <div class="footer-nav">
                            <p>Info</p>

                            <?php if (knot_menu_exists('contact')) : ?>
                                <?php wp_nav_menu([
                                        'theme_location' => 'contact',
                                        'container' => '',
                                        'items_wrap' => '<ul>%3$s</ul>',
                                ]); ?>
                            <?php endif; ?>

                            <?php if (knot_menu_exists('social')) : ?>
                                <?php wp_nav_menu([
                                        'theme_location' => 'social',
                                        'container' => 'nav',
                                        'container_class' => 'socials',
                                        'items_wrap' => '<ul>%3$s</ul>',
                                ]); ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        <div class="footer-bottom flex-center-between">
            <p class="footer-copyright"><?php echo $copyright; ?></p>
            <button class="footer-up" onclick="scrollToElement('html', {easing: sharpStartSlowEnd})"></button>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>

</body>
</html>
