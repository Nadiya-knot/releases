import {toggleController} from './modules/toggle/toggleController.min.js';
import {scrollController} from './modules/scrollController.min.js';
import {mediaController} from './modules/mediaController.min.js';
import './modules/scrollToElement.min.js';
import {smoothScrollLinks} from './modules/smoothScrollLinks.min.js';

import {headerScrollHandler} from './handlers/headerScrollHandler.min.js';
import {modalClickHandler} from './handlers/modalClickHandler.min.js';
import {mediaResizeHandler} from './handlers/mediaResizeHandler.min.js';
import {numberUpHandler} from './handlers/numberUpHandler.min.js';
import {animOnScrollHandler} from './handlers/animOnScrollHandler.min.js';


document.addEventListener('DOMContentLoaded', () => {
    // --- Toggles ---
    toggleController.init('.header_user_info', '.header_user', {hover: '.header_user'});
    toggleController.init('.burger', '.menu');

    // --- Scroll Logic ---
    scrollController.init(numberUpHandler);
    // OR
    scrollController.init((scrollData) => numberUpHandler(scrollData, {defaultDuration: 2000}));

    scrollController.init(headerScrollHandler);
    scrollController.init(animOnScrollHandler);


    // --- Modals ---
    window.addEventListener('click', modalClickHandler);

    // --- Media / Resize ---
    mediaController.init(mediaResizeHandler);

    // --- Автоматично підключаємо плавну прокрутку для всіх внутрішніх посилань ---
    smoothScrollLinks();
});