import {scrollController} from './modules/scrollController.min.js';
import {mediaController} from './modules/mediaController.min.js';
import {swiperController} from './modules/swiperController.min.js';
import {smoothScrollLinks} from './modules/smoothScrollLinks.min.js';
import './modules/scrollToElement.min.js';

import {VideoController} from './modules/videoController.min.js';
import {numberUpHandler} from './handlers/numberUpHandler.min.js';

import {toggleController} from './modules/toggle/toggleController.min.js';
import {ToggleGroupController} from './modules/toggle/toggleGroupController.min.js';
import {modalClickHandler} from './handlers/modalClickHandler.min.js';

import {headerScrollHandler} from './handlers/headerScrollHandler.min.js';
import {slideUp, slideDown} from './libs/miniAnimate.min.js';

const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent),
	isTouch = (('ontouchstart' in window) || (navigator.maxTouchPoints > 0) || (navigator.msMaxTouchPoints > 0));

const initFormTabs = () => {
    document.querySelectorAll('.form-right').forEach(container => {
        const tabs = container.querySelectorAll('.form-tabs button');
        const forms = {
            msg: container.querySelector('.form-tab-wpcf7'),
            call: container.querySelector('.form-tab-book')
        };

        if (tabs.length !== 2) return;

        tabs.forEach((btn, index) => {
            btn.addEventListener('click', () => {
                tabs.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                if (index === 0) {
                    slideDown(forms.msg, 300);
                    slideUp(forms.call, 300);
                } else {
                    slideDown(forms.call, 300);
                    slideUp(forms.msg, 300);
                }
            });
        });
    });
};

let lenis = false;
const smothScroll = () => {
    return;
	if (!isSafari || !isTouch) {
		lenis = new Lenis();
		function raf(time) {
			lenis.raf(time)
			requestAnimationFrame(raf)
		}

		requestAnimationFrame(raf)
	}
}

document.addEventListener('DOMContentLoaded', () => {
    const root = document.documentElement;
    const header = document.querySelector('header');
    const burger = document.querySelector('.burger');
    const mobileMenu = document.querySelector('.menu');

    const blocks = document.querySelectorAll('.what-li:not(:last-child)');
    const initialScale = 1;
    const minScale = 0.85;

    // Зберігаємо початкову позицію кожного блоку
    function getOriginalTop(el) {
        const oldPosition = el.style.position;
        el.style.position = 'static';
        const top = el.getBoundingClientRect().top;
        el.style.position = oldPosition;
        return top;
    }

    const blocksData = Array.from(blocks).map(el => ({
        el,
        startTop: getOriginalTop(el) + window.scrollY - el.offsetHeight
    }));


    // Common
    if (header) {
        header.classList.add('header-loaded');

        mediaController.init(({width}) => {
            root.style.setProperty('--header', `${header.offsetHeight}px`);
        });
    }
    window.addEventListener('click', modalClickHandler);
    if (burger && mobileMenu) {
        const instance = toggleController.init(burger, mobileMenu, {useDisplay: true});
        const html = document.documentElement;

        // Зберігаємо оригінальні методи
        const originalOpen = instance.open.bind(instance);
        const originalClose = instance.close.bind(instance);

        // Перевизначаємо open() і close(), додаючи клас .overflow-hidden
        instance.open = function () {
            originalOpen();
            html.classList.add('overflow-hidden');
        };

        instance.close = function () {
            originalClose();
            html.classList.remove('overflow-hidden');
        };
    }
    numberUpHandler({scrollY: window.scrollY});
    initFormTabs();
    smothScroll();

    // Toggle
    const groupController = new ToggleGroupController()
    document.querySelectorAll('.faq-li').forEach((el) => {
        const trigger = el.querySelector('.faq-trigger');
        const content = el.querySelector('.faq-content');

        const instance = toggleController.init(trigger, content, {
            useDisplay: true,
            onOpen: () => el.classList.add('active'),
            onClose: () => el.classList.remove('active')
        });
        groupController.add(instance);
    });

    // Video
    new VideoController();

    // Scroll
    scrollController.init((data) => {
        headerScrollHandler(data);
        numberUpHandler(data);

        blocksData.forEach(({el, startTop}) => {
            const windowHeight = window.innerHeight;

            const scrolled = scrollY - startTop;
            const progress = Math.min(Math.max(scrolled / windowHeight, 0), 1);

            const scale = initialScale - (initialScale - minScale) * progress;
            el.style.transform = `scale(${scale})`;
        });
    });

    smoothScrollLinks();

    // Swiper
    const autoplay = {
        loop: true,
        autoplay: {
            delay: 0,
            disableOnInteraction: false,
        },
        speed: 6000,
        allowTouchMove: false,
        on: {
            autoplayStart: function () {
                this.el.classList.add('swiper-linear');
            },
        },
    };
    swiperController.init('.partners-swiper.swiper:not(.swiper-initialized)', {
        spaceBetween: 0,
        slidesPerView: 2,
        breakpoints: {
            768: {slidesPerView: 4, spaceBetween: 16},
            1024: {slidesPerView: 5, spaceBetween: 36},
        },
        ...autoplay,
    });
    swiperController.init('.reviews-list.swiper:not(.swiper-initialized)', {
        spaceBetween: 12,
        slidesPerView: 'auto',
        breakpoints: {
            768: {slidesPerView: 2, spaceBetween: 16},
            1024: {slidesPerView: 3, spaceBetween: 36},
        },
    });
    swiperController.init('.how-list.swiper:not(.swiper-initialized)', {
        spaceBetween: 20,
        slidesPerView: 'auto',
    });

    // Contact form 7 re-direct
    document.addEventListener('wpcf7mailsent', function (event) {
        location = knot.thank_link;
    }, false);
});