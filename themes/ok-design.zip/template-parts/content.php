<?php if (!defined('ABSPATH')) exit;

$post_id = get_the_ID();
$content = get_post_field('post_content', $post_id);
$index = 0;

$blocks = parse_blocks($content);

$block_to_display = 'carbon-fields';


foreach ($blocks as $block) {
    $is_crb = strstr($block['blockName'], '/', true);

    if ($is_crb === $block_to_display || $block['blockName'] === 'core/block') {
        if ($index !== 0) {
            $index = 0; ?>
            </section>
        <?php }
        echo render_block($block);
    } elseif ($block['blockName'] === 'core/shortcode' && trim($block['innerHTML']) == '[wlfmc_wishlist]') {
        if ($index !== 0) {
            $index = 0; ?>
            </section>
        <?php }

        echo do_shortcode($block['innerHTML']);
    } else {
        if (!isset($block['blockName'])) {
            echo render_block($block);
        } else {
            if ($index === 0) { ?>
                <section class="container richText">
                    <?php if ($block['blockName'] === 'core/shortcode'): ?>
                        <?php echo do_shortcode($block['innerHTML']); ?>
                    <?php else: ?>
                        <div class="text">
                	       <?php echo render_block($block); ?>
                       </div>
                    <?php endif ?>
                    <?php $index++; ?>
            <?php } else {
                echo render_block($block);
            }
        }
    }
}

if ($index !== 0) { ?>
</section>
<?php }