<?php
/**
 * Theme bootstrap file
 * @package YourTheme
 */

if (!defined('ABSPATH')) exit;

// === Глобальні константи ===
$theme = wp_get_theme();
define('THEME_VERSION', $theme->get('Version'));
define('THEME_TEXT_DOMAIN', $theme->get('TextDomain') ?? 'custom-theme');
define('THEME_DIR', get_template_directory());
define('THEME_URI', get_template_directory_uri());

if (!class_exists('ThemeLoader')) {
    class ThemeLoader
    {
        private string $base_dir;
        private array $dirs = ['functions', 'inc'];
        private string $admin_context = 'admin';
        private array $file_cache = [];

        public function __construct(array|string|null $context = null, ?string $file = null, string $base_dir = THEME_DIR)
        {
            $this->base_dir = $base_dir;

            $this->load_context($context ?? $this->dirs, $file);
        }

        /**
         * Завантажує контекст (директорії або окремий файл), підтримка вкладених масивів
         */
        private function load_context(array|string $context, ?string $file = null): void
        {
            if (!is_array($context)) {
                $this->load_context_file($context, $file);
                return;
            }

            foreach ($context as $key => $item) {
                if (is_array($item)) {
                    foreach ($item as $subFile) {
                        $this->load_context_file($key, $subFile);
                    }
                } else {
                    if (is_numeric($key)) {
                        $this->load_context_file($item);
                    } else {
                        $this->load_context_file($key, $item);
                    }
                }
            }
        }

        /**
         * Завантажує конкретний файл у контексті з кешуванням
         */
        private function load_context_file(string $context, ?string $file = null): void
        {
            if ($context === $this->admin_context && !is_admin()) return;

            $file = $file ?? 'index.php';
            if (pathinfo($file, PATHINFO_EXTENSION) !== 'php') {
                $file .= '.php';
            }

            $base = $this->base_dir . '/' . $context . '/' . $file;

            if (isset($this->file_cache[$base])) {
                return;
            }

            if (file_exists($base)) {
                require_once $base;
                $this->file_cache[$base] = true;
            } elseif (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("ThemeLoader: Файл не знайдено - {$base}");
            }
        }
    }
}

// Ініціалізація
new ThemeLoader();