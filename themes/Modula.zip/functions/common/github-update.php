<?php
if (!defined('ABSPATH')) exit;

class GitHub_Theme_Updater
{
    private $repo = 'Nadiya-knot/releases';
    private $theme_slug;
    private $current_version;
    private $cache_enabled;
    private $cache_key = 'github_theme_update_';
    private $cache_time = 12 * HOUR_IN_SECONDS;
    private $fail_time = 30 * MINUTE_IN_SECONDS;

    public function __construct($cache_enabled = true)
    {
        $this->init_theme_data();
        $this->cache_enabled = $cache_enabled;

        add_filter('site_transient_update_themes', [$this, 'check_update']);
    }

    private function init_theme_data()
    {
        $theme = wp_get_theme();
        $this->theme_slug = $theme->get_stylesheet();
        $this->current_version = $theme->get('Version');
    }

    public function check_update($transient)
    {
        if (empty($transient->checked)) return $transient;

        if ($this->cache_enabled && $cached = $this->get_cache()) {
            if (version_compare($this->current_version, $cached['new_version'], '<')) {
                $transient->response[$this->theme_slug] = $cached;
                return $transient;
            }
        }

        $release = $this->get_latest_release();
        if (!$release) return $transient;

        $update_info = $this->prepare_update_info($release);
        if ($update_info && version_compare($this->current_version, $update_info['new_version'], '<')) {
            $transient->response[$this->theme_slug] = $update_info;
            $this->set_cache($update_info);
        }

        return $transient;
    }

    private function get_cache()
    {
        return get_transient($this->cache_key . $this->theme_slug);
    }

    private function set_cache($data, $time = null)
    {
        if (!$this->cache_enabled) return;
        $duration = $time ?: $this->cache_time;
        set_transient($this->cache_key . $this->theme_slug, $data, $duration);
    }

    private function get_latest_release()
    {
        $response = wp_remote_get("https://api.github.com/repos/{$this->repo}/releases", [
            'headers' => ['User-Agent' => 'WordPress/' . get_bloginfo('version')],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            $this->set_cache(['new_version' => $this->current_version], $this->fail_time);
            return false;
        }

        $releases = json_decode(wp_remote_retrieve_body($response));
        if (empty($releases) || !is_array($releases)) {
            $this->set_cache(['new_version' => $this->current_version], $this->fail_time);
            return false;
        }

        foreach ($releases as $release) {
            if (strpos($release->tag_name, $this->theme_slug . '-') === 0) {
                return $release;
            }
        }

        return false;
    }

    private function prepare_update_info($release)
    {
        $new_version = ltrim(str_replace($this->theme_slug . '-', '', $release->tag_name), 'v');

        $download_url = $this->get_download_url($release);

        return [
            'theme' => $this->theme_slug,
            'new_version' => $new_version,
            'url' => $release->html_url,
            'package' => $download_url,
        ];
    }

    private function get_download_url($release)
    {
        if (!empty($release->assets) && isset($release->assets[0]->browser_download_url)) {
            return $release->assets[0]->browser_download_url;
        }

        return "https://raw.githubusercontent.com/{$this->repo}/main/themes/{$this->theme_slug}.zip";
    }
}

new GitHub_Theme_Updater();