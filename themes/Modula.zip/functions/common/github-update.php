<?php
if (!defined('ABSPATH')) exit;

class GitHub_Theme_Updater
{
    private $repo = 'Nadiya-knot/releases';
    private $themes = [];
    private $cache_enabled;
    private $cache_key = 'github_theme_update_';
    private $cache_time = 12 * HOUR_IN_SECONDS;
    private $fail_time = 30 * MINUTE_IN_SECONDS;

    public function __construct($cache_enabled = true)
    {
        $this->cache_enabled = $cache_enabled;
        $this->init_theme_data();
        add_filter('site_transient_update_themes', [$this, 'check_update']);

        add_action('upgrader_process_complete', [$this, 'clear_cache_after_update'], 10, 2);
    }

    private function init_theme_data()
    {
        $theme = wp_get_theme();
        $this->themes[] = [
            'slug' => $theme->get_stylesheet(),
            'version' => $theme->get('Version')
        ];

        if ($theme->parent()) {
            $parent = $theme->parent();
            $this->themes[] = [
                'slug' => $parent->get_stylesheet(),
                'version' => $parent->get('Version')
            ];
        }
    }

    public function check_update($transient)
    {
        if (empty($transient->checked)) return $transient;

        foreach ($this->themes as $theme) {
            $slug = $theme['slug'];
            $current_version = $theme['version'];

            $cached = $this->cache_enabled ? $this->get_cache($slug) : false;

            if ($cached) {
                if (version_compare($current_version, $cached['new_version'], '<')) {
                    $transient->response[$slug] = $cached;
                }
                continue;
            }

            $release = $this->get_latest_release($slug);
            if (!$release) {
                $this->set_cache($slug, ['new_version' => $current_version], $this->fail_time);
                continue;
            }

            error_log("ffhttps://raw.githubusercontent.com/{$this->repo}/main/themes/{$slug}.zip");
            $update_info = $this->prepare_update_info($slug, $release);

            if ($update_info && version_compare($current_version, $update_info['new_version'], '<')) {
                $transient->response[$slug] = $update_info;
                $this->set_cache($slug, $update_info);
            } else {
                $this->set_cache($slug, ['new_version' => $current_version]);
            }
        }

        return $transient;
    }

    private function get_cache($slug)
    {
        return get_transient($this->cache_key . $slug);
    }

    private function set_cache($slug, $data, $time = null)
    {
        if (!$this->cache_enabled) return;
        $duration = $time ?: $this->cache_time;
        set_transient($this->cache_key . $slug, $data, $duration);
    }

    private function get_latest_release($slug)
    {
        $response = wp_remote_get("https://api.github.com/repos/{$this->repo}/releases", [
            'headers' => ['User-Agent' => 'WordPress/' . get_bloginfo('version')],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            $this->set_cache($slug, ['new_version' => '0'], $this->fail_time);
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $releases = json_decode($body);
        if (empty($releases) || !is_array($releases)) {
            $this->set_cache($slug, ['new_version' => '0'], $this->fail_time);
            return false;
        }

        foreach ($releases as $release) {
            if (stripos($release->tag_name, $slug . '-') === 0) {
                return $release;
            }
        }

        return false;
    }

    private function prepare_update_info($slug, $release)
    {
        $new_version = ltrim(str_ireplace($slug . '-', '', $release->tag_name), 'v');
        $download_url = $this->get_download_url($slug, $release);

        return [
            'theme' => $slug,
            'new_version' => $new_version,
            'url' => $release->html_url,
            'package' => $download_url,
        ];
    }

    private function get_download_url($slug, $release)
    {
        if (!empty($release->assets)) {
            return $release->assets[0]->browser_download_url;
        }
        return "https://raw.githubusercontent.com/{$this->repo}/main/themes/{$slug}.zip";
    }

    public function clear_cache_after_update($upgrader, $options)
    {
        if ($options['type'] === 'theme' && !empty($options['themes'])) {
            foreach ($options['themes'] as $theme_slug) {
                delete_transient($this->cache_key . $theme_slug);
            }
        }
    }
}

new GitHub_Theme_Updater();