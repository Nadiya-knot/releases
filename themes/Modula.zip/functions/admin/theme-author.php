<?php
if (!defined('ABSPATH')) exit;

class ThemeFooter
{
    public function __construct()
    {
        add_filter('admin_footer_text', [$this, 'author_text']);
    }

    public function author_text()
    {
        $theme = wp_get_theme();
        $author = $theme->get('Author');
        $author_uri = $theme->get('AuthorURI');

        echo $this->build_author_text($author, $author_uri);
    }

    private function build_author_text($author, $author_uri)
    {
        $text_prefix = esc_html__('Тему розроблено', THEME_TEXT_DOMAIN);

        if ($author && $author_uri) {
            $author_html = sprintf(
                ' <a href="%s" target="_blank" rel="noopener noreferrer">%s</a>',
                esc_url($author_uri),
                esc_html($author)
            );
        } elseif ($author) {
            $author_html = ' ' . esc_html($author);
        } else {
            return esc_html__('Тему розроблено невідомим автором', THEME_TEXT_DOMAIN);
        }

        return $text_prefix . $author_html;
    }
}

new ThemeFooter();