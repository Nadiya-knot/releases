<?php

namespace Theme\Functions\Frontend\TopBar\Toggle;

if (!defined('ABSPATH')) exit;

class TopBarToggle
{

    private string $meta_name = 'admin_bar_checkbox';

    public function __construct()
    {
        add_action('admin_bar_menu', [$this, 'add_checkbox_to_admin_bar'], 100);
        add_action('init', [$this, 'handle_post']);
        add_filter('show_admin_bar', [$this, 'toggle_admin_bar']);
//        add_action('wp_footer', [$this, 'floating_checkbox']);
    }

    private function is_enabled(): bool
    {
        if (!is_user_logged_in()) return false;
        $value = get_user_meta(get_current_user_id(), $this->meta_name, true);
        if ($value === '') {
            update_user_meta(get_current_user_id(), $this->meta_name, 1);
            return true;
        }
        return (bool)$value;
    }

    public function add_checkbox_to_admin_bar($wp_admin_bar)
    {
        if (!is_user_logged_in() || !$this->is_enabled()) return;

        $checked = $this->is_enabled() ? 'checked' : '';

        $form = sprintf(
            '<form method="post" style="margin:0;">
                <input type="hidden" name="update_%1$s" value="1">
                <input type="checkbox" name="%1$s" onchange="this.form.submit();" %2$s>
            </form>',
            esc_attr($this->meta_name),
            $checked
        );

        $wp_admin_bar->add_node([
            'id' => 'custom_checkbox',
            'title' => $form,
            'parent' => 'top-secondary',
        ]);
    }

    public function handle_post()
    {
        if (!is_user_logged_in() || empty($_POST['update_' . $this->meta_name])) return;

        $value = isset($_POST[$this->meta_name]) ? 1 : 0;
        update_user_meta(get_current_user_id(), $this->meta_name, $value);

        wp_redirect($_SERVER['REQUEST_URI']);
        exit;
    }

    public function toggle_admin_bar($show)
    {
        if (!is_user_logged_in()) return $show;
        return $this->is_enabled();
    }

    // Плаваючий чекбокс, коли адмін-бар прихований
    public function floating_checkbox()
    {
        if (!is_user_logged_in() || $this->is_enabled()) return;

        $checked = $this->is_enabled() ? 'checked' : '';
        $meta_name = esc_attr($this->meta_name);

        echo <<<HTML
            <div style="
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 9999;
                background: #fff;
                border: 1px solid #ddd;
                padding: 10px;
                border-radius: 5px;
                box-shadow: 0 2px 6px rgba(0,0,0,0.2);
            ">
                <form method="post" style="margin:0;">
                    <input type="hidden" name="update_{$meta_name}" value="1">
                    <input type="checkbox" name="{$meta_name}" onchange="this.form.submit();" {$checked}>
                </form>
            </div>
        HTML;
    }
}

new TopBarToggle();