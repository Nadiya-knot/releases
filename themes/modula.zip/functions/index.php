<?php
/*
 * theme/functions/index.php
 */

if (!defined('ABSPATH')) exit;

if (class_exists('Modula_Loader')) {
    new Modula_Loader([
        'frontend' => [
            'customize/index',
            'top-bar/toggle',
        ],
        'admin' => [
            'theme-author'
        ],
        'common' => [
            'github-update'
        ]
    ], null, __DIR__);
}