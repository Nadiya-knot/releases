<?php
/**
 * Theme bootstrap file
 * @package YourTheme
 */

if (!defined('ABSPATH')) exit;

// === Глобальні константи ===
$theme = wp_get_theme();
define('MODULA_VERSION', $theme->get('Version'));
define('MODULA_TEXT_DOMAIN', $theme->get('TextDomain') ?? 'custom-theme');
define('MODULA_DIR', get_template_directory());
define('MODULA_URI', get_template_directory_uri());

if (!class_exists('Modula_Loader')) {
    class Modula_Loader
    {
        private string $base_dir;
        private array $dirs = ['functions', 'inc'];
        private string $admin_context = 'admin';
        private array $file_cache = [];

        public function __construct(array|string|null $context = null, ?string $file = null, string $base_dir = MODULA_DIR)
        {
            $this->base_dir = $base_dir;

            $this->load_context($context ?? $this->dirs, $file);
        }

        /**
         * Завантажує контекст (директорії або окремий файл), підтримка вкладених масивів
         */
        private function load_context(array|string $context, ?string $file = null): void
        {
            if (!is_array($context)) {
                $this->load_context_file($context, $file);
                return;
            }

            foreach ($context as $key => $item) {
                if (is_array($item)) {
                    foreach ($item as $subFile) {
                        $this->load_context_file($key, $subFile);
                    }
                } else {
                    if (is_numeric($key)) {
                        $this->load_context_file($item);
                    } else {
                        $this->load_context_file($key, $item);
                    }
                }
            }
        }

        /**
         * Завантажує конкретний файл у контексті з кешуванням
         */
        private function load_context_file(string $context, ?string $file = null): void
        {
            if ($context === $this->admin_context && !is_admin()) return;

            $base_dir = $this->base_dir . '/' . $context;

            if ($file === '*') {
                // Підключаємо всі PHP файли в папці
                foreach (glob($base_dir . '/*.php') as $f) {
                    if (isset($this->file_cache[$f])) continue;
                    require_once $f;
                    $this->file_cache[$f] = true;
                }
                return;
            }

            $file = $file ?? 'index.php';
            if (pathinfo($file, PATHINFO_EXTENSION) !== 'php') {
                $file .= '.php';
            }

            $base = $base_dir . '/' . $file;

            if (isset($this->file_cache[$base])) {
                return;
            }

            if (file_exists($base)) {
                require_once $base;
                $this->file_cache[$base] = true;
            } elseif (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("Modula_Loader: Файл не знайдено - {$base}");
            }
        }
    }
}

// Ініціалізація
new Modula_Loader();