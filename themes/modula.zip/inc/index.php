<?php
/*
 * theme/inc/index.php
 */

if (!defined('ABSPATH')) exit;

if (class_exists('Modula_Loader')) {
    $loader = new Modula_Loader([
        'frontend' => [

        ],
        'admin' => [

        ]
    ], null, __DIR__);
}