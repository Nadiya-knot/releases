<?php
/*
 * theme/functions/index.php
 */

if (!defined('ABSPATH')) exit;

if (class_exists('ThemeLoader')) {
    new ThemeLoader([
        'frontend' => [
            'top-bar/toggle'
        ],
        'admin' => [

        ],
    ], null, __DIR__);
}