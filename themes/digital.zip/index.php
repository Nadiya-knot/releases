<?php get_header(); ?>

<main>
    <?php
    $datetime = get_option('custom_datetime', '');
    $datetime_clean = str_replace('T', ' ', $datetime);
    ?>
    <ul class="data-datetime">
        <li><span>00</span><span>D</span></li>
        <li><span>00</span><span>H</span></li>
        <li><span>00</span><span>M</span></li>
        <li><span>00</span><span>S</span></li>
    </ul>

    <?php
    wp_nav_menu([
            'theme_location' => 'social',
            'container' => 'ul',
            'menu_class' => 'social-menu',
            'walker' => new Social_Menu_Walker()
    ]);
    ?>

    <script>
        (function () {
            const targetTime = new Date('<?php echo $datetime_clean; ?>').getTime();
            const ul = document.querySelector('.data-datetime');
            const lis = ul.querySelectorAll('li');

            function pad(num) {
                return num.toString().padStart(2, '0');
            }

            function updateCountdown() {
                const now = new Date().getTime();
                let diffMs = Math.max(0, targetTime - now); // різниця в мс

                const days = Math.floor(diffMs / 86400000); // 1000*60*60*24
                diffMs %= 86400000;

                const hours = Math.floor(diffMs / 3600000);
                diffMs %= 3600000;

                const minutes = Math.floor(diffMs / 60000);
                diffMs %= 60000;

                const seconds = Math.floor(diffMs / 1000);

                lis[0].querySelector('span:first-child').textContent = pad(days);
                lis[1].querySelector('span:first-child').textContent = pad(hours);
                lis[2].querySelector('span:first-child').textContent = pad(minutes);
                lis[3].querySelector('span:first-child').textContent = pad(seconds);
            }

            updateCountdown();
            setInterval(updateCountdown, 1000); // оновлюємо щосекунди
        })();
    </script>


    <?php
    $theme = get_option('custom_theme', 'light');

    $light_desktop = wp_get_attachment_url(get_option('light_desktop'));
    $light_mobile = wp_get_attachment_url(get_option('light_mobile'));
    $dark_desktop = wp_get_attachment_url(get_option('dark_desktop'));
    $dark_mobile = wp_get_attachment_url(get_option('dark_mobile'));
    ?>
    <video id="adaptive-video" autoplay muted loop playsinline preload="metadata"></video>

    <script>
        (function () {
            const video = document.getElementById('adaptive-video');

            // Визначаємо потрібні URL відео
            const theme = '<?php echo $theme; ?>';
            const urls = {
                light: {
                    desktop: '<?php echo esc_url($light_desktop); ?>',
                    mobile: '<?php echo esc_url($light_mobile); ?>'
                },
                dark: {
                    desktop: '<?php echo esc_url($dark_desktop); ?>',
                    mobile: '<?php echo esc_url($dark_mobile); ?>'
                }
            };

            function updateVideo() {
                const isDesktop = window.innerWidth > window.innerHeight;
                const src = isDesktop ? urls[theme].desktop : urls[theme].mobile;

                if (video.src !== src) {
                    video.src = src;
                    video.load();
                }
            }

            window.addEventListener('resize', updateVideo);
            updateVideo(); // одразу при завантаженні
        })();
    </script>
</main>

<?php get_footer(); ?>
