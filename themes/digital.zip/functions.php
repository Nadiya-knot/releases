<?php

if (!defined('ABSPATH')) exit;

// Додаємо меню у адмінку
add_action('admin_menu', 'custom_admin_page');
function custom_admin_page()
{
    add_menu_page(
            'Налаштування заглушки',
            'Заглушка',
            'manage_options',
            'custom-video-page',
            'render_custom_admin_page',
            'dashicons-format-video',
            20
    );
}

// Підключаємо скрипти для медіа-завантажувача
add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook != 'toplevel_page_custom-video-page') return;
    wp_enqueue_media();
    wp_enqueue_script('custom-admin-js', plugin_dir_url(__FILE__) . 'custom-admin.js', ['jquery'], null, true);
});

// Відображення сторінки
function render_custom_admin_page()
{
    // Отримуємо збережені значення
    $datetime = get_option('custom_datetime', '');
    $theme = get_option('custom_theme', 'light');
    $videos = [
            'light_desktop' => get_option('video_light_desktop', ''),
            'light_mobile' => get_option('video_light_mobile', ''),
            'dark_desktop' => get_option('video_dark_desktop', ''),
            'dark_mobile' => get_option('video_dark_mobile', ''),
    ];

    if (isset($_POST['custom_submit'])) {
        if (isset($_POST['custom_datetime'])) {
            update_option('custom_datetime', sanitize_text_field($_POST['custom_datetime']));
        }
        if (isset($_POST['custom_theme'])) {
            update_option('custom_theme', sanitize_text_field($_POST['custom_theme']));
        }
        foreach ($videos as $key => $val) {
            if (isset($_POST[$key])) {
                update_option($key, intval($_POST[$key])); // зберігаємо ID медіафайлу
            }
        }
        echo '<div class="updated"><p>Налаштування збережено!</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>Налаштування заглушки</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>Дата та час</th>
                    <td><input type="datetime-local" name="custom_datetime" value="<?php echo esc_attr($datetime); ?>"/>
                    </td>
                </tr>
                <tr>
                    <th>Тема</th>
                    <td>
                        <select name="custom_theme">
                            <option value="light" <?php selected($theme, 'light'); ?>>Світла</option>
                            <option value="dark" <?php selected($theme, 'dark'); ?>>Чорна</option>
                        </select>
                    </td>
                </tr>
                <?php
                $labels = [
                        'light_desktop' => 'Світла тема - Desktop відео',
                        'light_mobile' => 'Світла тема - Mobile відео',
                        'dark_desktop' => 'Чорна тема - Desktop відео',
                        'dark_mobile' => 'Чорна тема - Mobile відео',
                ];
                foreach ($labels as $key => $label) :
                    $video_id = get_option($key, '');
                    $video_url = $video_id ? wp_get_attachment_url($video_id) : '';
                    ?>
                    <tr>
                        <th><?php echo $label; ?></th>
                        <td>
                            <input type="hidden" name="<?php echo $key; ?>" id="<?php echo $key; ?>"
                                   value="<?php echo esc_attr($video_id); ?>"/>
                            <button class="upload_video_button button" data-target="<?php echo $key; ?>">Вибрати відео
                            </button>
                            <div id="<?php echo $key; ?>_preview">
                                <?php if ($video_url) : ?>
                                    <video width="200" src="<?php echo esc_url($video_url); ?>" controls></video>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
            <?php submit_button('Зберегти', 'primary', 'custom_submit'); ?>
        </form>
    </div>
    <?php
}

add_action('admin_footer', 'custom_admin_footer');
function custom_admin_footer()
{ ?>
    <script>
        jQuery(document).ready(function ($) {
            $('.upload_video_button').click(function (e) {
                e.preventDefault();
                var button = $(this);
                var target = button.data('target');

                var frame = wp.media({
                    title: 'Виберіть відео',
                    library: {type: 'video'},
                    multiple: false
                });

                frame.on('select', function () {
                    var attachment = frame.state().get('selection').first().toJSON();

                    // Перевірка типу файлу
                    if (!attachment.mime || attachment.mime.indexOf('video') === -1) {
                        alert('Помилка: обрано не відео!');
                        return;
                    }

                    $('#' + target).val(attachment.id);
                    $('#' + target + '_preview').html('<video width="200" src="' + attachment.url + '" controls></video>');
                });

                frame.open();
            });

            // Додатково можна перевіряти перед відправкою форми
            $('form').on('submit', function (e) {
                var valid = true;
                $('.upload_video_button').each(function () {
                    var target = $(this).data('target');
                    if ($('#' + target).val() === '') {
                        alert('Будь ласка, оберіть відео для ' + target);
                        valid = false;
                        return false; // вихід з each
                    }
                });
                if (!valid) e.preventDefault();
            });
        });
    </script>
<?php }

add_filter('body_class', function ($classes) {
    $theme = get_option('custom_theme', 'light');

    $classes[] = 'theme-' . $theme;
    return $classes;
});

add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('theme-style', get_stylesheet_uri());
});