<?php

if (!defined('ABSPATH')) exit;

add_action('init', function () {
    register_nav_menus([
        'social' => 'Соц мережі',
    ]);
});

// Додаємо поле тільки для меню з локацією "social"
add_filter('wp_nav_menu_item_custom_fields', function ($item_id, $item, $depth, $args) {

    // Перевірка: працюємо лише для меню "social"
    $locations = get_nav_menu_locations();
    $social_menu_id = $locations['social'] ?? 0;
    if (!$social_menu_id) return;

    wp_enqueue_media();

    $image_id = get_post_meta($item_id, '_menu_item_image_id', true);
    $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'thumbnail') : '';

    ?>
    <p class="description description-wide menu-item-custom-field">
        <label>Іконка:</label><br>
        <img src="<?php echo esc_url($image_url); ?>"
             style="max-width:60px;<?php echo $image_url ? '' : 'display:none;'; ?>"
             class="menu-item-icon-preview">

        <input type="hidden" name="menu_item_image_id[<?php echo $item_id; ?>]"
               class="menu-item-icon-field"
               value="<?php echo esc_attr($image_id); ?>">

        <button class="button select-menu-icon">Обрати</button>
        <button class="button remove-menu-icon" <?php echo $image_id ? '' : 'style="display:none;"'; ?>>Видалити</button>
    </p>

    <script>
    jQuery(function($){
        let frame;
        $('.menu-item-custom-field').off('click').on('click', '.select-menu-icon', function(e){
            e.preventDefault();
            const box = $(this).closest('.menu-item-custom-field');
            if (!frame) frame = wp.media({ title: 'Обрати іконку', multiple: false });
            frame.off('select').on('select', function(){
                const attachment = frame.state().get('selection').first().toJSON();
                box.find('.menu-item-icon-field').val(attachment.id);
                box.find('.menu-item-icon-preview').attr('src', attachment.url).show();
                box.find('.remove-menu-icon').show();
            });
            frame.open();
        });

        $('.menu-item-custom-field').on('click', '.remove-menu-icon', function(e){
            e.preventDefault();
            const box = $(this).closest('.menu-item-custom-field');
            box.find('.menu-item-icon-field').val('');
            box.find('.menu-item-icon-preview').hide();
            $(this).hide();
        });
    });
    </script>
    <?php
}, 10, 4);


// Збереження
add_action('wp_update_nav_menu_item', function ($menu_id, $item_id) {
    if (isset($_POST['menu_item_image_id'][$item_id])) {
        update_post_meta($item_id, '_menu_item_image_id', (int) $_POST['menu_item_image_id'][$item_id]);
    }
}, 10, 2);

class Social_Menu_Walker extends Walker_Nav_Menu {
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $image_id = get_post_meta($item->ID, '_menu_item_image_id', true);

        // Вивід іконки (SVG або звичайне зображення)
        $icon = '';
        if ($image_id) {
            $mime = get_post_mime_type($image_id);
            $url = wp_get_attachment_url($image_id);

            $icon = '<span class="menu-icon" style="mask-image: url(' . $url . '"></span>';
        }

        $output .= '<li class="menu-item">';
        $output .= '<a href="' . esc_url($item->url) . '">' . $icon . '</a>';
    }
}