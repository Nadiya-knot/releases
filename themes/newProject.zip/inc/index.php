<?php
/*
 * theme/inc/index.php
 */

if (!defined('ABSPATH')) exit;

if (class_exists('ThemeLoader')) {
    $loader = new ThemeLoader([
        'frontend' => [

        ],
        'admin' => [

        ]
    ], null, __DIR__);
}